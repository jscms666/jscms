-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2019-10-18 02:38:40
-- 服务器版本： 5.5.61-log
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql_666_36yunhu_`
--

-- --------------------------------------------------------

--
-- 表的结构 `my_banner`
--

CREATE TABLE IF NOT EXISTS `my_banner` (
  `id` int(11) NOT NULL,
  `fl` int(10) NOT NULL,
  `pic` varchar(100) NOT NULL COMMENT '图片',
  `time` varchar(32) NOT NULL COMMENT '时间',
  `times` varchar(100) NOT NULL DEFAULT '00',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `links` varchar(100) NOT NULL COMMENT '连接',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `dj` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `my_banner`
--

INSERT INTO `my_banner` (`id`, `fl`, `pic`, `time`, `times`, `title`, `links`, `show`, `dj`) VALUES
(1, 1, '/uploads/20190613/cf7081b8507c607ffcb01d4310051def.jpg', '1559657278', '00', '二次开发', 'http://3gh.cc', 1, 0),
(2, 1, '/uploads/20190613/61d8c1ae6cd78349a4cd4ced82c98b50.gif', '1559729270', '00', '广告位招租', 'http://www.akhu.cc/', 1, 0),
(5, 1, '/uploads/20190613/9af273491ef95f23fe1ab63759d636d7.gif', '1560080841', '00', '网址导航管理系统qq群', 'http://18jj.xyz/', 1, 0),
(6, 2, '/uploads/20190613/9af273491ef95f23fe1ab63759d636d7.gif', '1561621442', '00', '广告', 'http://mm.dainb.cc', 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `my_category`
--

CREATE TABLE IF NOT EXISTS `my_category` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL COMMENT '上级',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1' COMMENT '侧栏',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `pic` varchar(100) NOT NULL COMMENT '图片',
  `time` varchar(32) NOT NULL COMMENT '时间',
  `keywords` varchar(100) NOT NULL COMMENT '关键词',
  `description` varchar(200) NOT NULL COMMENT '描述'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `my_category`
--

INSERT INTO `my_category` (`id`, `tid`, `name`, `type`, `show`, `sidebar`, `sort`, `pic`, `time`, `keywords`, `description`) VALUES
(1, 0, '设计素材', 1, 1, 1, 10, '', '1492058517', '设计素材', '设计素材');

-- --------------------------------------------------------

--
-- 表的结构 `my_comment`
--

CREATE TABLE IF NOT EXISTS `my_comment` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL COMMENT '上级评论',
  `uid` int(11) NOT NULL COMMENT '所属会员',
  `fid` int(11) NOT NULL COMMENT '所属帖子',
  `time` varchar(11) NOT NULL COMMENT '时间',
  `praise` varchar(11) NOT NULL COMMENT '赞',
  `reply` varchar(11) NOT NULL COMMENT '回复',
  `content` text NOT NULL COMMENT '内容'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `my_html`
--

CREATE TABLE IF NOT EXISTS `my_html` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL COMMENT '上级',
  `uid` int(11) NOT NULL DEFAULT '1' COMMENT '用户',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精贴',
  `settop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '顶置',
  `praise` varchar(11) DEFAULT NULL COMMENT '赞',
  `view` int(100) NOT NULL,
  `time` varchar(11) NOT NULL DEFAULT '0' COMMENT '时间',
  `reply` varchar(11) DEFAULT NULL COMMENT '回复',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `content` text COMMENT '内容',
  `pic` varchar(1000) DEFAULT NULL COMMENT '导航封面',
  `qq` varchar(1000) DEFAULT NULL COMMENT '站长QQ',
  `icos` int(11) DEFAULT NULL,
  `lianjie` varchar(1000) DEFAULT NULL COMMENT '网址链接',
  `ico` varchar(1000) DEFAULT NULL COMMENT '网站ico',
  `pingfen` int(10) NOT NULL DEFAULT '0' COMMENT '评分',
  `px` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `tool` int(11) NOT NULL DEFAULT '0' COMMENT '是否工具'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `my_html`
--

INSERT INTO `my_html` (`id`, `tid`, `uid`, `title`, `open`, `choice`, `settop`, `praise`, `view`, `time`, `reply`, `keywords`, `description`, `content`, `pic`, `qq`, `icos`, `lianjie`, `ico`, `pingfen`, `px`, `tool`) VALUES
(1, 8, 1, '免元素', 1, 1, 1, '271', 396, '1492058788', '2', '贵州省', '&lt;p&gt;任何技术问题都可以去社区发帖或者QQ群询问，我们会在第一时间解决你的问题。&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '免抠png、素材网站 免元素(mys360.com)是一个大型综合设计类免抠网站，提供免费透明素材下载，是作为您是设计师的灵感根据地，每天我们会不断更新大量素材，更多免抠png图片素材等着你来下载。 ', '/uploads/20190613/7d7fdf28e6327b89f95dbafbdef8908f.jpg', '', 1, '3gh.cc', '', 0, 10, 0);

-- --------------------------------------------------------

--
-- 表的结构 `my_links`
--

CREATE TABLE IF NOT EXISTS `my_links` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL COMMENT '名称',
  `links` varchar(100) NOT NULL COMMENT '连接',
  `time` varchar(32) NOT NULL COMMENT '时间',
  `pic` varchar(100) NOT NULL COMMENT '图片',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `fl` int(11) NOT NULL,
  `px` int(10) NOT NULL,
  `dj` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `my_links`
--

INSERT INTO `my_links` (`id`, `name`, `links`, `time`, `pic`, `show`, `fl`, `px`, `dj`) VALUES
(1, '文章', '/news.html', '1560261373', '', 1, 0, 1, 0),
(2, '排行榜', '/top.html?type=today', '1560508267', '', 1, 0, 1, 0),
(3, '社区', 'http://www.akhu.cc/default.html', '1561022505', '', 1, 0, 0, 1),
(4, '最近更新', '/wang.html', '1561378468', '', 1, 0, 10, 0);

-- --------------------------------------------------------

--
-- 表的结构 `my_member`
--

CREATE TABLE IF NOT EXISTS `my_member` (
  `userid` int(11) NOT NULL,
  `key` int(1) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `userip` varchar(32) NOT NULL COMMENT 'IP',
  `username` varchar(32) NOT NULL COMMENT '名称',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `kouling` varchar(32) NOT NULL COMMENT '口令',
  `userhead` varchar(100) NOT NULL COMMENT '头像',
  `usermail` varchar(32) NOT NULL COMMENT '邮箱',
  `regtime` varchar(32) NOT NULL COMMENT '注册时间',
  `grades` tinyint(1) NOT NULL DEFAULT '0' COMMENT '等级',
  `sex` tinyint(1) NOT NULL DEFAULT '1' COMMENT '性别',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '验证',
  `userhome` varchar(32) NOT NULL COMMENT '家乡',
  `description` varchar(200) NOT NULL COMMENT '描述'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `my_member`
--

INSERT INTO `my_member` (`userid`, `key`, `point`, `userip`, `username`, `password`, `kouling`, `userhead`, `usermail`, `regtime`, `grades`, `sex`, `status`, `userhome`, `description`) VALUES
(1, 0, 32, '127.0.0.1', '1417232670', '16e0c197e42a6be3', '5201314', '/uploads/20170401/default.png', 'admin@admin.com', '1491037613', 1, 1, 1, '', '');

-- --------------------------------------------------------

--
-- 表的结构 `my_news`
--

CREATE TABLE IF NOT EXISTS `my_news` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL DEFAULT '1' COMMENT '上级',
  `uid` int(11) NOT NULL DEFAULT '1',
  `sttop` int(1) NOT NULL DEFAULT '0',
  `show` int(1) NOT NULL DEFAULT '1',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `view` varchar(11) NOT NULL COMMENT '浏览量',
  `time` varchar(11) NOT NULL COMMENT '时间',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `content` text COMMENT '内容'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `my_news`
--

INSERT INTO `my_news` (`id`, `tid`, `uid`, `sttop`, `show`, `title`, `view`, `time`, `keywords`, `description`, `content`) VALUES
(1, 1, 1, 1, 1, '宜宾天空变色系地震云?网警辟谣:灯光折射天空引起', '19', '1561290818', '', '', '&lt;p&gt;（原标题：宜宾天空变色，是地震云？网警辟谣：系灯光折射天空引起）&lt;/p&gt;&lt;p&gt;新京报快讯 据宜宾网警巡查执法微博消息，6月22日晚，宜宾朋友圈和各个群被地震刷屏的同时，几段夜晚天空莫名变色的视频也引起了大家的关注。&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://dingyue.ws.126.net/94XqfOzPBV2ukTaF2goio2Dmgftg6pqk4NEaHdGwOmvtt1561283483838.png&quot;&gt;图片：视频截图&lt;/p&gt;&lt;p&gt;视频中可以看到，天空颜色不断变化，一会红，一会黄，一会紫，还有小女孩的声音出现在视频中表示很害怕。那么，这究竟是怎么回事?天空为什么会变色?&lt;/p&gt;&lt;p&gt;很快真相被查明:这是宜宾中坝大桥上的灯光折射天空所引起，并非是由地震引发。&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;宜宾网警提醒：对于不明情况的消息，希望大家不要胡乱猜测，更不要胡乱传播引起恐慌，发现谣言请及时举报!&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;'),
(2, 1, 1, 1, 1, '河南一男子杀害3人砍伤7人 潜逃近22年终被抓获', '22', '1561290937', '', '', '&lt;p&gt;（原标题：杀害3人砍伤7人 河南一嫌犯潜逃近22年终被抓获）&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://dingyue.ws.126.net/eo2IDgxYe7QUBjhWD7BuRUB1Ms8RN6TnnHIbBz2NIGh=a1561277344192compressflag.jpg&quot;&gt;图片来源 东方市公安局微信公众号&lt;/p&gt;&lt;p&gt;新京报快讯 据海南省东方市公安局微信公众号消息，2019年6月23日上午，东方市公安局通过河南警方提供的一名故意杀人逃犯可能隐藏在我市的信息，在缜密分析研判和多警种密切配合下，成功抓获一名潜逃近22年“一案三命”杀人嫌犯。&lt;/p&gt;&lt;p&gt;2019年6月18日，河南警方到东方市公安局要求配合抓捕故意杀人犯李某伟。经查证，李某伟涉嫌于1997年12月14日凌晨1时许，在河南省襄城县丁营乡楼李村伙同李某战持刀将村民李某、邵某、王某三人杀害，同时将7个村民砍伤、抢走信贷社3万元现金后潜逃至今尚未归案。&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;鉴于案情重大，东方市委常委、公安局局长刘殚指示刑警、网监、八所派出所等多警种密切配合，经过缜密侦查，最终锁定嫌疑人活动轨迹。2019年6月23日上午10时许，在东方市公安局优势警力围捕下，将犯罪嫌疑人李某伟成功抓获。目前，已将犯罪嫌疑人李某伟移交河南警方作进一步审查。&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;'),
(3, 1, 1, 1, 1, '少年肛周手术后33天死亡 家属:去世后医院仍收费', '45', '1561291021', '', '', '                  &lt;p&gt;（原标题：云南16岁少年术后33天死亡，家属：去世已2天医院仍收费）是&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/b33ac15330fac16164fd9ae52ed36d83.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;生前，邓琅杰跟母亲、弟弟一起在捞渔河湿地公园。 家属供图&lt;/p&gt;&lt;p&gt;为给16岁的儿子邓琅杰治疗肛周脓肿，母亲代兴艳选择了她认为云南最好的医院——云南省第一人民医院（又称昆华医院，以下简称“昆华医院”），仍没能保住孩子的性命。&lt;/p&gt;&lt;p&gt;2019年4月24日14时30分许，邓琅杰在昆华医院肛肠科进行肛周脓肿切开引流术后，很快出现了寒战、抽搐、神志不清等症状。&lt;/p&gt;&lt;p&gt;从肛肠科转进该院ICU重症监护室后，医院连续下达了多次病危通知。经该院多科室和省内外专家会诊，邓琅杰术后继发感染，于5月27日9时58分不幸去世。&lt;/p&gt;&lt;p&gt;邓琅杰去世两天后，其家属前往医院结账时意外发现，医院在5月28日和29日仍对多个治疗项目进行收费。对此，家属分别向ICU急诊和该院投诉科反映，至今未获答复。&lt;/p&gt;&lt;p&gt;昆华医院工作人员6月17日告诉澎湃新闻，该事件已上报至云南省卫健委，因目前要走司法程序，不便回应。&lt;/p&gt;&lt;p&gt;术前检查申请单写错性别，做前列腺B超遭拒绝&lt;/p&gt;&lt;p&gt;16岁的邓琅杰，是云南农业大学附属中学高二年级男生，肛周脓肿已烦扰他多时。母亲代兴艳告诉澎湃新闻，2018年8月，儿子就因该病在昆华医院进行切开引流术治疗，“第二天就出院了，医生说半年后复查。”&lt;/p&gt;&lt;p&gt;4月22日，在校读书的邓琅杰打电话给母亲，称病情复发感到疼痛。&lt;/p&gt;&lt;p&gt;4月23日，在向学校请假后，代兴艳夫妇带着儿子到昆华医院检查。当日，邓琅杰入院后，前次曾为他手术的肛肠科主治医生建议其住院治疗。&lt;/p&gt;&lt;p&gt;交费后，医生给邓琅杰开具了心电图、肛门镜等检查清单。澎湃新闻发现，其中一份腹部超声检查申请单上，邓琅杰的性别被误写为女，但B超检查的项目是“肝胆胰脾肾前列腺门静脉”。&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/311f0cf98c2f4bdf2b500bd71d207dfd.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;邓琅杰的性别被误写为女，去超声科检查前列腺时被医生拒绝。&amp;nbsp;澎湃新闻记者 王万春&amp;nbsp;图&lt;/p&gt;&lt;p&gt;家属称，当天下午，邓琅杰拿着这份检查清单前往该院超声科检查时，被超声科医生拒绝。“超声科的医生说，到底是男生还是女生，哪有女生还做前列腺检查的？”代兴艳回忆。&lt;/p&gt;&lt;p&gt;术前，昆华医院肛肠科出具的邓琅杰病情评估表显示，在评估等级“一般”、“病重”、“病危”3个评估等级中，邓琅杰属于一般病人；其手术风险评估表也显示，他是正常患者，除局部病变外，无系统疾病，手术可在3小时内完成。&lt;/p&gt;&lt;p&gt;当天15时45分左右，手术结束，家属回忆，从手术室轮椅上被推出来时，邓琅杰意识清醒，但仅20分钟后，他开始浑身发抖、抽搐、寒战，“又过了10分钟后，我们叫他没有反应，休克了。”&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/b5df3edb4c3daee2b6ac88388a6acad2.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;邓琅杰入院当天，昆华医院的病情评估表&amp;nbsp;。&amp;nbsp;澎湃新闻记者 王万春&amp;nbsp;图&lt;/p&gt;&lt;p&gt;肛周脓肿手术后休克，医院数次下达病危通知&lt;/p&gt;&lt;p&gt;医护人员随即在肛肠科病房内对邓琅杰实施抢救，抢救进行两个半小时后，仍不见好转。&lt;/p&gt;&lt;p&gt;当天18时05分，该院肛肠科第一次给家属下达了病危通知书，当时的诊断为：1、意识障碍诱因待查，2、呼吸衰竭待查，3、阵发性室上性心动过速，4、肛周脓肿。&lt;/p&gt;&lt;p&gt;该病危通知书称，上述情况会随时引发危及患者生命的并发症，邓恩来在该份病危通知书上签了字。&lt;/p&gt;&lt;p&gt;当天19时许，邓琅杰从肛肠科病房转入ICU急诊。4月24日、25日，ICU急诊接连给家属下达病危通知书，内容均与肛肠科下达的病危通知书一致。&lt;/p&gt;&lt;p&gt;此后，每隔两三天，医院都会为邓琅杰组织会诊。多份院内会诊单显示，参与会诊的科室涉及肛肠科、心血管内科、麻醉手术科、血液科及ICU急诊等十多个科室。&lt;/p&gt;&lt;p&gt;除了院内会诊，昆华医院也曾请省内外医院专家为邓琅杰会诊。其中，广州医科大学附属第一医院感染内科专家5月14日的会诊记录显示：该患者病期分三个阶段，肛周脓肿、手术后发生休克、休克抢救期下呼吸继发院内感染；肛周脓肿考虑细菌感染，肠杆菌科细菌为致病菌，后期为继发感染；休克考虑过敏性休克为主，合并有感染因素。同时提到，既往可能存在基础疾病（入院时查出尿蛋白++，原因不明）。&lt;/p&gt;&lt;p&gt;5月15日，中山大学附属第一医院ICU科专家的远程会诊记录显示，此次会诊诊断与14日相同，专家建议抗感染治疗。同时，因患者意识状态不好，该专家建议先不拔管。&lt;/p&gt;&lt;p&gt;5月16日。原先处于持续昏迷状态的邓琅杰清醒过来，这让家属又增添了一丝希望。“从5月16日开始，他的状态逐渐好转，意识清醒，每天都好一点，到5月19日时状态最好，能跟我们打招呼。”家属说。&lt;/p&gt;&lt;p&gt;5月19日22时50分，昆华医院ICU急诊的主治医生让邓恩来在一份“气管拔管知情同意书”上签字。邓恩来说，在这份同意书上他手写的“我要求拔出气管”系按照医生要求填写。&lt;/p&gt;&lt;p&gt;该同意书显示，根据邓琅杰肛周脓肿的病情，医院给出了治疗方案。同时，该份同意书中，患者自身存在的高危因素一栏未填写；但在拔气管治疗可能出现的风险一栏包括了心跳呼吸停止、危及生命、急性心梗等所有选项。&lt;/p&gt;&lt;p&gt;当日23时06分，医院ICU急诊给邓琅杰气管拔管，并停止了呼吸机辅助通气。&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/d31918f54d7562aa861745f5ed5ca5d8.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;肛周脓肿手术后，肛肠科第一次下病危通知书 。&amp;nbsp;澎湃新闻记者 王万春&amp;nbsp;图&lt;/p&gt;&lt;p&gt;术后33天身亡，去世两天后医院仍收治疗费&lt;/p&gt;&lt;p&gt;5月25日，有护士告知家属，他们尚欠医疗费用1万余元。26日15时左右，代兴艳一次性交纳了3万元，“我想交了3万元，还能多出两万多点。”&lt;/p&gt;&lt;p&gt;5月27日9时57分，邓琅杰的生命在昆华医院ICU急诊画下句点。医院出具的病故通知单显示，邓琅杰的死亡诊断为：1、脓毒性休克；2、鲍曼不动杆菌败血症；3、肺炎克雷伯菌败血症；4、感染性多器官功能衰竭；5、肺部感染；6、肛周脓肿术后；7、肛瘘；8、室上性心动过速。&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/b8893d847fd1893b7c63054831c4ef2b.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;昆华医院给邓琅杰家属的病故通知单 。&amp;nbsp;澎湃新闻记者 王万春&amp;nbsp;图&lt;/p&gt;&lt;p&gt;家属称，5月29日，他们前往医院收费窗口清账，却遭到ICU急诊的阻拦，该科室要求他们必须在ICU收费窗口进行清账，并要求家属再交纳9万元医疗费用。&lt;/p&gt;&lt;p&gt;这一举动引起了家属的怀疑，“我们每天交费，没有欠过医疗费，26日下午交了3万元后还有多余两万元，27日早上9点多人就死了，短短10多个小时，要花费12万元医疗费？”&lt;/p&gt;&lt;p&gt;“我们要ICU急诊打出每日清单明细供核对，但ICU收费窗口的说打不出来，只有清账后才能打出清单。”家属向澎湃新闻提供了数十页邓琅杰的住院日清单称，29日晚，他们在医院一楼大厅终端机自行打出了清单。&lt;/p&gt;&lt;p&gt;邓琅杰的住院日清单显示，5月28日ICU急诊对邓琅杰的收费项目还包括进口动脉采血器等。清单上的费用日期是5月28日至29日，其中收费项目有3项，其余显示已退费。“27日人就死了，28日、29日还在收费，要不是我们打清单快，根本就发现不了。”家属说。&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;少年肛周手术后33天死亡 家属:去世后医院仍收费&quot; src=&quot;http://crawl.ws.126.net/12cdf22dc7f0fcee77bea91be886feb4.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;5月27日9时许医院宣布邓琅杰死亡，5月28日医院还在收费的住院日清单 。&amp;nbsp;澎湃新闻记者 王万春&amp;nbsp;图&lt;/p&gt;&lt;p&gt;家属告诉澎湃新闻，自邓琅杰入院以来，他们共计交纳现金33万元（不含医保报销的15.8万元），加上“还欠的9万元”，整个治疗费用将近60万元。&lt;/p&gt;&lt;p&gt;家属还透露，在送进ICU急诊抢救之后，医生要求他们每天到医院附近的药店购买指定品牌和指定厂家生产的药品，也花去近10万元，“比如静注人免疫球蛋白，这个药很贵，医生指定要深圳一个制药厂生产的，我们找遍医院外面的药店，只有一家有这个药厂的，买药时该药店还要求登记医院、科室、床位和主治医生的信息等。”&lt;/p&gt;&lt;p&gt;家属提供的发票显示，4月25日，家属向昆明惟郎特肿瘤药品有限公司购买了6000元的静注人免疫球蛋白。发票显示，直至5月27日邓琅杰去世，家属在该公司多次购买静注人免疫球蛋白。&lt;/p&gt;&lt;p&gt;对此，据业内人士指出，如果医生指定院外购买的药品对患者有实际帮助，且不可替代，符合规定；但是，如果同样疗效的药品有多个规格和厂家，可以替代，医生指定院外购买不符合相关规定。澎湃新闻查询发现，像静注人免疫球蛋白就有多个生产厂家。&lt;/p&gt;&lt;p&gt;此外，家属说，他们在比对住院费用汇总清单时发现，清单上的药品数量跟医嘱不相符，“比如氯化钠要比医嘱上多出181瓶，7000多元的伏立康唑片在医嘱上根本没有，美罗培南也比医嘱要多出20瓶来，有些药根本不在医嘱里，到底用过没有都不知道。”&lt;/p&gt;&lt;p&gt;针对上述疑点，家属表示，他们已分别向ICU急诊和医院投诉科反映，至今未获答复。&lt;/p&gt;&lt;p&gt;澎湃新闻掌握的证据显示，该医院ICU急诊负责人答复家属时称，收费项目确实存在医保报销比例信息对接错误的情况，“我们也很吃惊，我们这边确实有错误，其它的我无法给你一个准确的答复，因为这个已经超出了我的能力范围。”该负责人说。&lt;/p&gt;&lt;p&gt;6月4日，昆华医院工作人员向澎湃新闻表示，待该事件调查清楚后做详细回应。6月17日，该院答复称，已将事件上报至云南省卫健委，待卫健委批准调查清楚后作回应；而后，该院又回复称，因为目前要走司法程序，医院不便回应。&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;6月21日，邓琅杰的家属告诉澎湃新闻，儿子的遗体至今仍在医院太平间内，但账没有清，后事没有办，医院目前也没有任何答复。&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;'),
(4, 1, 1, 1, 1, '我不是为了生气而…', '24', '1561619874', '', '&lt;p&gt;有一位禅师非常喜爱兰花，在平日弘法讲经之余，心费了许多的&lt;a href=&quot;http://www.duwenzhang.com/huati/shijian/index1.html&quot;&gt;时间&lt;/a&gt;栽种兰花。有一天，他要外出云游一段时间，临行前交待弟子：要好好照顾寺里的兰花。在这段期间，弟子们总是细心照顾兰花，但有一天在浇水时却不小心将兰花架', '                  &lt;p&gt;有一位禅师非常喜爱兰花，在平日弘法讲经之余，心费了许多的时间栽种兰花。有一天，他要外出云游一段时间，临行前交待弟子：要好好照顾寺里的兰花。在这段期间，弟子们总是细心照顾兰花，但有一天在浇水时却不小心将兰花架碰倒了，所有的兰花盆都失碎了，兰花散了满地。弟子们都因此非常恐慌，打算等师父回来后，向师父赔罪领罚。&lt;/p&gt;&lt;p&gt;禅师回来了，闻知此事，便召&lt;a href=&quot;http://18jj.xyz/&quot; target=&quot;_blank&quot;&gt;集弟子们&lt;/a&gt;，不但没有责怪，反而说道：“我种兰花，一来是希望用来供佛，二来也是为了美化寺里环境，不是为了生气而种兰花的。”&lt;/p&gt;&lt;p&gt;　　禅师说得好：“不是为了生气而种兰花的。”而禅师之所以看得开，是因为他虽然喜欢兰花，但心中却无兰花这个挂碍。&lt;/p&gt;&lt;p&gt;　　因此，兰花的得失，并不影响他心中的喜怒。同样地，在日常中，我们牵挂得太多，我们太在意得失，所以我们的情绪起伏，我们不快乐。&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;　　在生气之际，我们如能多想想：“我不是为了生气而工作的。”“我不是为了生气而教书的。”“我不是为了生气而交朋友的。”“我不是为了生气而生儿育女的。”那么我们会为我们烦恼的心情辟出另一番安祥。&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;'),
(5, 1, 1, 1, 1, '抖音2019最火前20首歌 抖音歌曲排行榜2019最新', '17', '1561646854', '', '&lt;h3 style=&quot;text-align: center;&quot;&gt;抖音2019最火前20首歌&lt;/h3&gt;&lt;p style=&quot;text-align: center;&quot;&gt;1.出山——王胜男&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;2.生僻字——陈柯宇&lt;/', '            &lt;h3 style=&quot;text-align: center;&quot;&gt;抖音2019最火前20首歌&lt;/h3&gt;&lt;p style=&quot;text-align: center;&quot;&gt;1.出山——王胜男&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;2.生僻字——陈柯宇&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;3.沙漠骆驼——夏雨菲&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;4.盗将行——马雨阳&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;5.狂浪——花姐&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;6.绿色——陈雪凝&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;7.往后余生——马良&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;8.有一种悲伤——A-Lin&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;9.春风十里——鹿先森乐队&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;10.一百万个可能——christine we&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;11.学猫叫——小峰峰&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;12.38度6——黑龙&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;13.写给黄淮——解忧邵帅&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;14.纸短情长——烟把儿&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;15.有可能的夜晚——曾轶可&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;16.病变——Cubi&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;17.最美的期待——周笔畅&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;18.红昭愿——音阙诗听&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;19.慢慢喜欢你——莫文蔚&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;20.改革春风吹满地——抖音音乐&lt;/p&gt;&lt;h3 style=&quot;text-align: center;&quot;&gt;抖音歌曲排行榜2019最新&lt;/h3&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《出山》&lt;/p&gt;&lt;p style=&quot;text-align: center; &quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104328765.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;民谣歌手花粥的这一首《&lt;a href=&quot;http://www.akhu.cc&quot; target=&quot;_blank&quot;&gt;出山&lt;/a&gt;》可以说在抖音火得不得了，平均十个视频里就有一首是它，当之无愧的最火没有之一。曲风很独特，歌词感觉像是在对伪善者的讽刺，也有网友调侃，循环了好多遍，再听就感觉自己要出家了。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《有可能的夜晚》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104333396.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;曾轶可13年发布的一首歌曲，今年突然在抖音里面火了起来。说起曾轶可，其实不少人印象还停留在《狮子座》，但这个特立独行的女孩其实也非常有才。这首《有可能的夜晚》其中一句歌词，“让蜡烛代替所有灯 让音乐代替话语声 此时无声胜有声”给人无尽的遐想。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《预谋》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104338665.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;歌曲一开始的旋律就很抓耳，歌词十分的通俗易懂，引起了不少网友的共鸣。尤其是高潮的一句：“反正 他都不难受 他只要自由 他都不会理会我的感受”感情中，你也遇到过这样的情况吗？&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《盗将行》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104342756.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;花粥的另一首歌曲，收录在18年专辑《粥请客（二）》里。还真不是谁都能翻唱的，这首歌曲还获得了18年度网易云音乐原创盛典年度十大歌曲奖。歌词“你的笑像一条恶犬 撞乱我心弦”曾在网上引起了不小的争议。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《一百万个可能》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104347518.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;初次听到这首歌曲怎么都没有想到是一个外国友人演唱的，歌词写的十分的唯美。歌词很励志的感觉，给了不少人以鼓舞，所以在抖音也十分的火，还有一个男生翻唱版也很不错。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《倒数》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104352375.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;“铁肺小天后”邓紫棋的又一首高音作品，整首歌曲表达的也是好好珍惜的美好含义。歌曲由邓紫棋作词作曲，真正的小才女，从开头就让人惊艳，邓紫棋用她磅礴穿透的歌声，冲破自我与时间的枷锁，回答她对爱的执着！&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《下坠》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104356835.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;很适合一个人的时候听的歌曲，在抖音火了之后，各种翻唱版本都出来了，无论男生版还是女生版都很惊艳。歌曲的旋律正如歌名一样，让人有一种不断下坠的感觉，很不错的作品。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《清明上河图》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104401608.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;古风满满的一首歌，歌词描写的也很唯美。高潮部分戏腔的唱法非常的惊艳，整首歌曲充满了“李玉刚韵味”。李玉刚用古典而又时尚的演绎方式，用轻快的语调带领我们“乐”读了这一传世名画。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《侧脸》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104406485.jpg&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;歌曲《侧脸》于19年发行，原唱是歌手于果，最让人印象深刻的是一句“曾经是心心念念 随随便便深深浅浅 爱上了不语不言不计前嫌不知疲倦”。歌曲描述了一段分手之后的心理历程，不少人表示听完有共鸣。&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;《水星记》&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;抖音2019最火前20首歌 抖音歌曲排行榜2019最新&quot; src=&quot;https://img.ixiumei.com/uploadfile/2019/0406/20190406104411755.jpg&quot;&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; &quot;&gt;又是一首很适合一个人听的歌曲，《水星记》发行于16年，歌曲MV17年入围了第28届台湾金曲奖最佳音乐录像带奖。郭顶用其高辨识度的声线，完美的演绎了这首歌曲，“还要多远才能进入你的心 还要多久才能和你接近”你感受到了这种爱而不得的感觉吗？&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;br&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- 表的结构 `my_newscate`
--

CREATE TABLE IF NOT EXISTS `my_newscate` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL COMMENT '上级',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `sort` int(10) NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `pic` varchar(100) NOT NULL COMMENT '图片',
  `time` varchar(32) NOT NULL COMMENT '时间',
  `keywords` varchar(100) NOT NULL COMMENT '关键词',
  `description` varchar(200) NOT NULL COMMENT '描述'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `my_newscate`
--

INSERT INTO `my_newscate` (`id`, `tid`, `name`, `type`, `sort`, `show`, `pic`, `time`, `keywords`, `description`) VALUES
(1, 0, '实时新闻', 1, 1, 1, '/uploads/20190624/4d60c9d933004bd4605cddcf2ca5ab8b.jpg', '1561372551', '实时新闻', '实时新闻');

-- --------------------------------------------------------

--
-- 表的结构 `my_top`
--

CREATE TABLE IF NOT EXISTS `my_top` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '1',
  `tid` int(11) NOT NULL COMMENT '上级',
  `show` int(1) NOT NULL DEFAULT '1',
  `time` varchar(11) NOT NULL COMMENT '时间',
  `view` int(100) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `my_wang`
--

CREATE TABLE IF NOT EXISTS `my_wang` (
  `id` int(11) NOT NULL,
  `uid` int(10) NOT NULL,
  `tid` int(11) NOT NULL COMMENT '上级',
  `open` int(1) NOT NULL DEFAULT '1',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `lianjie` varchar(1000) NOT NULL,
  `view` varchar(11) NOT NULL COMMENT '浏览量',
  `time` varchar(11) NOT NULL COMMENT '时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `my_wangcate`
--

CREATE TABLE IF NOT EXISTS `my_wangcate` (
  `id` int(11) NOT NULL,
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `sort` int(10) NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `pic` varchar(100) NOT NULL COMMENT '图片',
  `time` varchar(32) DEFAULT NULL COMMENT '时间',
  `keywords` varchar(100) NOT NULL COMMENT '关键词',
  `description` varchar(200) NOT NULL COMMENT '描述'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `my_banner`
--
ALTER TABLE `my_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_category`
--
ALTER TABLE `my_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_comment`
--
ALTER TABLE `my_comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_html`
--
ALTER TABLE `my_html`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_links`
--
ALTER TABLE `my_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_member`
--
ALTER TABLE `my_member`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `my_news`
--
ALTER TABLE `my_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_newscate`
--
ALTER TABLE `my_newscate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_top`
--
ALTER TABLE `my_top`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_wang`
--
ALTER TABLE `my_wang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_wangcate`
--
ALTER TABLE `my_wangcate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `my_banner`
--
ALTER TABLE `my_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `my_category`
--
ALTER TABLE `my_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `my_comment`
--
ALTER TABLE `my_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `my_html`
--
ALTER TABLE `my_html`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `my_links`
--
ALTER TABLE `my_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `my_member`
--
ALTER TABLE `my_member`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `my_news`
--
ALTER TABLE `my_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `my_newscate`
--
ALTER TABLE `my_newscate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `my_top`
--
ALTER TABLE `my_top`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=143;
--
-- AUTO_INCREMENT for table `my_wang`
--
ALTER TABLE `my_wang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `my_wangcate`
--
ALTER TABLE `my_wangcate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
