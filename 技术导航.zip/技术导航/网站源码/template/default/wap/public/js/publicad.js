$(document).ready(function(){
	//电脑左下
	if(location.pathname=="/"||location.pathname=="/index.html"){
		$("body").append('<a href="http://www.qqjishuwang.com/" target="_blank" style="position: fixed;left: 50%;bottom: 45px;margin-left: -49%;"><img src="//static.daohangtx.com/static/img/gg/jsyw.png" /></a>');
	}
	
	//手机文字
	$(".page-group .indexWebList").prepend('<a href="https://www.115z.com/html/6324.html" target="_blank" style="text-align:center;height: 1rem;line-height: 1rem;overflow: hidden;color: #35c79b;font-size: 0.65rem;display: inline-block;margin-bottom: -0.5rem;margin-top: 0.5rem;padding-right: 1.5%;width: 50%;">厂家直销莆田AJ精仿鞋</a><a href="https://www.115z.com/html/11562.html" target="_blank" style="text-align:center;height: 1rem;line-height: 1rem;overflow: hidden;color: #35c79b;font-size: 0.65rem;display: inline-block;margin-bottom: -0.5rem;margin-top: 0.5rem;width: 50%;padding-left: 1.5%;">8元包邮拿到无限流量卡</a>')
	
	
	if(location.pathname=="/"||location.pathname=="/index.html"||location.pathname=="/m/"){
		if(getCookie("outerCountry")=="true"){
			addAd();
		}else{
			$.ajax({url:'https://api.ip138.com/query/?token=ca95900966f0257aa1a1043b799986b3&datatype=jsonp&callback=isip',dataType:'jsonp'});
		}
	}
});


function addAd(){
	//广告位招租
	var adssc = '<a href="tencent://Message/?Uin=1839577559&websiteName=www.qq.com&Menu=yes" target="_blank" style="display:block;margin:0px auto;width:1100px;border-radius:10px;"><img src="/img/66.gif" style="width:100%;margin-bottom:10px;" /></a>';
	$("body>.indexSearch").after(adssc);
	
}
function isip(ret){
	if(ret.ret=="ok" && ret.data){
		
		var arr = ['美国','日本',' 柬埔寨','菲律宾','韩国','澳大利亚','英国','加拿大','德国','法国','荷兰','巴西','俄罗斯','意大利','印度','老挝','新加坡','波兰','挪威','西班牙','越南','泰国','南非','马来西亚'];
		for(var i = 0;i<arr.length;i++){
			if(ret.data.toString().indexOf(arr[i])>=0){
				addAd();
				setCookie("outerCountry","true","d25");
				return;
			}
		}
	}
}