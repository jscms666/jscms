/*初始化导航条*/
setTimeout(function () {
    var liWidth = 0;
    $(".listNav li").forEach(function (item, index) {
        liWidth += parseInt($(item).width()) + parseInt($(item).css("margin-right"));
    });
    $(".listNav div").width(liWidth + 30);


    function iScrollClick() {
        if (/iPhone|iPad|iPod|Macintosh/i.test(navigator.userAgent)) return false;
        if (/Chrome/i.test(navigator.userAgent)) return (/Android/i.test(navigator.userAgent));
        if (/Silk/i.test(navigator.userAgent)) return false;
        if (/Android/i.test(navigator.userAgent)) {
            var s = navigator.userAgent.substr(navigator.userAgent.indexOf('Android') + 8, 3);
            return parseFloat(s[0] + s[3]) < 44 ? false : true
        }
    }
	
    new IScroll('.listNav', {
        scrollX: true,
        scrollY: false,
        mouseWheel: true,
        click: iScrollClick()
    });
    
}, 100);


/*流加载*/
var loading = true;
//上次加载的序号
var lastIndex = 1;
var itemsPerLoad = 15;

var page = 2;
var pages = Math.ceil(maxItems / itemsPerLoad);
// 每次加载添加多少条目
console.log(maxItems);
$(document).on('infinite', '.infinite-scroll', function () {


    // 如果正在加载，则退出
    if (!loading) return;
    // 设置flag


    // 重置加载flag
    loading = false;
    if (page > pages) {
        // 加载完毕，则注销无限加载事件，以防不必要的加载
        $.detachInfiniteScroll($('.infinite-scroll'));
        // 删除加载提示符
        $('.infinite-scroll-preloader').html("没有更多了");
        return;
    }
    $.ajax({
        url: config.api.get_type_list_page,
        data: {
            id: id,
            page: page,
        },
        success: function (res) {
            var html = '';
            console.log(res);
            for (var i = 0; i < res.data.length; i++) {
                html += '<li> ' +
                    '       <a href="/html/' + res.data[i].id + '.html" class="clearfix"> ' +
                    '           <div class="img"> ' +
                    '           <img src="//static.daohangtx.com' + res.data[i].logo_path + '"> ' +
                    '           </div> <p>' + (res.data[i].web_content == null ? "暂无介绍" : res.data[i].web_content) + '"></p> </a>' +
                    '  </li>'
            }
            // 添加新条目
            $(".web_list").append(html);
            loading = true
        }
    })
    page++;
    //容器发生改变,如果是js滚动，需要刷新滚动
    $.refreshScroller();
});






