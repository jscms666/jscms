if(!$.device.android && !$.device.ios){
	location = "/";
}

$(document).ready(function(){
	/*加载首页推荐区的滚动*/
	var mySwiper = new Swiper('.swiper-container', {
		scrollbar: {
			el: '.swiper-scrollbar',
		}
	});
	/*兼容更多分类的横向滚动*/
	var classWidth = 0;
	$(".classList ul li").each(function(index,item){
		classWidth += parseInt($(item).css("margin-right")) + parseInt($(item).width());
		
	});
	$(".classList ul").width(classWidth);
});

/*加载新闻*/
$.get("/api/get_news_list.html",function(res){
	var html = "";
	res.forEach(function(item,index){
		html += '<li> <a href="'+item.url+'" target="_blank" class="clearfix"> <div class="img"> <img src="'+item.thumbnail_pic_s+'" /> </div> <div class="info"> <h3>'+item.title+'</h3> </div> </a> </li>';
	});
	$(".news ul").html(html);
	
	//手机新闻
	$(".news ul li").eq(0).find(".info h3").text('淘宝购物，不知道这个技巧，白白浪费了几万块钱，知道这个省钱购物技巧小伙伴惊呆了');
	$(".news ul li").eq(0).find(".img img").attr('src','//static.daohangtx.com/static/img/gg/gaoyong.jpg');
	$(".news ul li").eq(0).find("a").attr('href','//static.daohangtx.com/static/img/gg/gaoyong1.jpg');
});

/*判断当前是否是直接打开网站的*/
if(getCookie("openType")=="detail"){
	$(".indexSet .checkbox").click();
	urlToDetail("detial");
}
$(".indexSet .checkbox").click(function(){
	var that = $(this);
	setTimeout(function(){
		if(that.parent().find("input").is(':checked')){
			$.toast("开启直接进入");
			setCookie("openType","url","d365");
			urlToDetail("url");
		}else{
			$.toast("关闭直接进入");
			setCookie("openType","detail","d365");
			urlToDetail("detial");
		}
	},200)
});
function urlToDetail(type){
	if(type=="url"){
		$("body a[data-detail]").forEach(function(item,index){
			$(item).attr("href",$(item).attr("data-url")).attr("target","_blank");
		});
	}else{
		$("body a[data-detail]").forEach(function(item,index){
			$(item).attr("href",$(item).attr("data-detail")).removeAttr("target");
		});
	}
}


/*搜索下拉框提示*/
var keyword = "";
$(".indexSearch input").bind("input",function(e){
	var that = $(this);
	if(keyword != that.val()){
		$.get("/test/bdkeyword.php?wd=" + that.val(),function(res){
			if(res){
				res = eval("("+res+")");
				var html = "";
				res.s.forEach(function(item,index){
					html += '<li> <a href="https://www.baidu.com/s?ie=utf-8&wd='+item+'" target="_blank">'+item+'</a> </li>';
				});
				
				if(html.trim()!=""){
					$(".selectKeyword").show().html(html);
				}else{
					$(".selectKeyword").hide().html("");
				}
			}else{
				$(".selectul").hide().html("");
			}
		});
	}else{
		$(".selectKeyword").hide();
	}
});
$(".indexSearch input").keyup(function(e){
	if(e.keyCode==13){
		window.open("https://www.baidu.com/s?ie=utf-8&wd=" + $(this).val() ,"_blank");
		$(".selectKeyword").hide();
	}
});
$(".selectKeyword").on("click","a",function(){
	$(".selectKeyword").hide();
});

