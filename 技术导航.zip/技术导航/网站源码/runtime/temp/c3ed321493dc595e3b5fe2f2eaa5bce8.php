<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:39:"./application/admin/view/news_edit.html";i:1561807524;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_header.html";i:1561296954;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_footer.html";i:1559657242;}*/ ?>
<!DOCTYPE html>
<html>
<head>  
  <title>Guojiz国际网址后台管理系统</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="/favicon.ico" rel="shortcut icon">
  <link rel="stylesheet" href="/public/layui/css/layui.css">
  <link rel="stylesheet" href="/public/css/global.css">
  <script src="/public/layui/layui.js" type="text/javascript"></script>
  <script src="/public/js/jquery-3.4.1.min.js" type="text/javascript"></script>
</head>
<link rel="stylesheet" href="/public/wangEditor/css/wangEditor.min.css">
<script type="text/javascript" src="/public/wangEditor/js/wangEditor.min.js"></script>
<body>
<div class="fly-panel fly-panel-user">
<div class="tpt—admin">
<fieldset class="layui-elem-field layui-field-title">
  <legend>修改</legend>
</fieldset>
   
<form class="layui-form">
  <input type="hidden" name="id" value="<?php echo $tptc['id']; ?>">

  <div class="layui-form-item" style="width: 300px;">
    <label class="layui-form-label">接入网站</label>
    <div class="layui-input-block">
      <select name="tid">
	  <?php if(is_array($tptcs) || $tptcs instanceof \think\Collection || $tptcs instanceof \think\Paginator): $i = 0; $__LIST__ = $tptcs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
      <option <?php if($tptc['tid'] == $vo['id']): ?>selected="selected"<?php endif; ?> value="<?php echo $vo['id']; ?>"><?php echo $vo['name']; ?></option>
      <?php endforeach; endif; else: echo "" ;endif; ?>
	  </select>
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">标题</label>
    <div class="layui-input-block">
      <input type="text" name="title" value="<?php echo $tptc['title']; ?>" required lay-verify="required" placeholder="请输入内容" autocomplete="off" class="layui-input">
    </div>
  </div>
 

		<div class="layui-form-item">
          <label for="L_title" class="layui-form-label">浏览量</label>
          <div class="layui-input-block">
            <input type="text" name="view" value="<?php echo $tptc['view']; ?>" autocomplete="off" class="layui-input" style="width: 100px;">
          </div>
        </div>
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">描述</label>
    <div class="layui-input-block">
      <textarea id="textarea" name="content" style="height:300px;width: 100%;">
      <?php echo $tptc['content']; ?></textarea>
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
	  <button class="layui-btn" lay-submit="" lay-filter="news_edit">立即提交</button>
      <button class="layui-btn layui-btn-primary" onclick="history.go(-1);return false;">返回</button>
    </div>
  </div>

</form>
</div>
</div>
<script type="text/javascript">
    var editor = new wangEditor('textarea');
	editor.config.uploadImgUrl = '<?php echo url("html/doUploadPic"); ?>';
	editor.config.uploadImgFileName = 'FileName';
    editor.create();
</script>
<script>
layui.use(['form', 'upload'],function(){
  var form = layui.form()
  ,jq = layui.jquery;
  
  layui.upload({
    url: '<?php echo url("upload/upimage"); ?>'
    ,elem:'#image'
    ,before: function(input){
      loading = layer.load(2, {
        shade: [0.2,'#000']
      });
    }
    ,success: function(res){
      layer.close(loading);
      jq('input[name=pic]').val(res.path);
      layer.msg(res.msg, {icon: 1, time: 1000});
    }
  });

  form.on('submit(news_edit)', function(data){
    loading = layer.load(2, {
      shade: [0.2,'#000']
    });
    var param = data.field;
    jq.post('<?php echo url("news/edit"); ?>',param,function(data){
      if(data.code == 200){
        layer.close(loading);
        layer.msg(data.msg, {icon: 1, time: 1000}, function(){
          location.href = '<?php echo url("news/index"); ?>';
        });
      }else{
        layer.close(loading);
        layer.msg(data.msg, {icon: 2, anim: 6, time: 1000});
      }
    });
    return false;
  });

})
</script>
<div class="footer">
  <p class="bq">
  <a style="position: absolute;color: #FFF;display: none;" class="banquan" target="_blank" href="https://www.guojiz.com/">国际网址导航</a>
  </p>
</div>
</body>
</html>