<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./application/admin/view/news_index.html";i:1561897008;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_header.html";i:1561296954;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_footer.html";i:1559657242;}*/ ?>
<!DOCTYPE html>
<html>
<head>  
  <title>Guojiz国际网址后台管理系统</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="/favicon.ico" rel="shortcut icon">
  <link rel="stylesheet" href="/public/layui/css/layui.css">
  <link rel="stylesheet" href="/public/css/global.css">
  <script src="/public/layui/layui.js" type="text/javascript"></script>
  <script src="/public/js/jquery-3.4.1.min.js" type="text/javascript"></script>
</head>
<body>
<style type="text/css">
.layui-form-checkbox {height: 22px;line-height: 20px;margin-right: 0px;padding-right: 20px;}
.layui-form-checkbox i {right: 3px;width: 20px;font-size: 16px;top: 2px;}
</style>
<div class="fly-panel fly-panel-user">
<div class="tpt—admin">
<div class="tpt—btn" style="float: left;margin: 0 20px 0 0">
<a href="<?php echo url('news/add'); ?>"><i class="layui-icon">&#xe608;</i> 添加</a>
</div>

<div style="float: left;">
<form class="layui-form" action="" method="get">
<input placeholder="输入关键字" name="ks" value="<?php echo input('ks');?>" type="text" class="layui-input" style="float: left;margin-right: 10px;width: 240px;">
<button class="layui-btn" style="float: left;" value="查询" type="submit">查询</button>
</form>
</div>

<form class="layui-form" enctype="multipart/form-data" method="post">
<table width="100%">
      <tr>
	    <th width="5%" align="center"><input type="checkbox" name="checkAll" lay-filter="checkAll"></th>
		<th width="5%" align="center">数据ID</th>
        <th width="20%" align="center">标题</th>
        <th width="20%" align="center">分类</th>
        <th width="10%" align="center">幻灯片【推荐】</th>
		<th width="10%" align="center">是否显示</th>
		<th width="10%" align="center">添加时间</th>
        <th width="10%" align="center">基本操作</th>
      </tr>
      <?php if(is_array($tptc) || $tptc instanceof \think\Collection || $tptc instanceof \think\Paginator): $i = 0; $__LIST__ = $tptc;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	  <tr>
	    <td align="center"><input type="checkbox" name="ids[<?php echo $vo['id']; ?>]" lay-filter="checkOne" value="<?php echo $vo['id']; ?>"></td>
		<td align="center"><?php echo $vo['id']; ?></td>
        <td style="padding-left: 20px;"><a target="_blank" href="/xq/<?php echo $vo['id']; ?>.html"><?php echo $vo['title']; ?></a></td>
        <td align="center"><b><font color="#ff0000">【<?php echo $vo['name']; ?>】</font></b></td>
		<td align="center">
		<a change="<?php echo $vo['id']; ?>" onclick="changesttop(this);" <?php if($vo['sttop'] == 1): ?>class="layui-unselect layui-form-switch layui-form-onswitch"<?php else: ?>class="layui-unselect layui-form-switch"<?php endif; ?>>
		<em>显示</em><i></i>
		</a>
		</td>
		<td align="center">
		<a change="<?php echo $vo['id']; ?>" onclick="changeshow(this);" <?php if($vo['show'] == 1): ?>class="layui-unselect layui-form-switch layui-form-onswitch"<?php else: ?>class="layui-unselect layui-form-switch"<?php endif; ?>>
		<em>显示</em><i></i>
		</a>
		</td>
		<td align="center"><?php echo date("Y-m-d",$vo['time']); ?></td>
        <td align="center"><a class="layui-btn layui-btn-mini layui-btn-warm" href="<?php echo url('news/edit',array('id'=>$vo['id'])); ?>">修改</a> <a class="layui-btn layui-btn-mini layui-btn-danger del_btn" member-id="<?php echo $vo['id']; ?>" title="删除" nickname="<?php echo $vo['title']; ?>">删除</a>
        </td>
      </tr>
      <?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<div class="layui-form-item">
<div style="margin-top: 20px;float: left;">
<button class="layui-btn" lay-submit lay-filter="delete">删除选中</button>
</div>
<div class="pages" style="float: right;"><?php echo $tptc->render(); ?></div>
</div>
</form>
<script>
function changesttop(o){
  var change=$(o).attr("change");
  $.ajax({
	  type:"post",
	  dataType:"json",
      data:{change:change},
	  url:"<?php echo url('news/changesttop'); ?>",
	  success:function(data){
		  if(data == 1){
			  $(o).attr("class","layui-unselect layui-form-switch");
	      }else{
			  $(o).attr("class","layui-unselect layui-form-switch layui-form-onswitch");
	      }
	  }
  });
}

function changeshow(o){
  var change=$(o).attr("change");
  $.ajax({
	  type:"post",
	  dataType:"json",
      data:{change:change},
	  url:"<?php echo url('news/changeshow'); ?>",
	  success:function(data){
		  if(data == 1){
			  $(o).attr("class","layui-unselect layui-form-switch");
	      }else{
			  $(o).attr("class","layui-unselect layui-form-switch layui-form-onswitch");
	      }
	  }
  });
}

</script>
<script>
layui.use('form',function(){
  var form = layui.form()
  ,jq = layui.jquery;

  jq('.del_btn').click(function(){
    var name = jq(this).attr('nickname');
    var id = jq(this).attr('member-id');
    layer.confirm('确定删除【'+name+'】?', function(index){
      loading = layer.load(2, {
        shade: [0.2,'#000']
      });
      jq.post('<?php echo url("news/dels"); ?>',{'id':id},function(data){
        if(data.code == 200){
          layer.close(loading);
          layer.msg(data.msg, {icon: 1, time: 1000}, function(){
            location.reload();
          });
        }else{
          layer.close(loading);
          layer.msg(data.msg, {icon: 2, anim: 6, time: 1000});
        }
      });
    });   
  });
  
  form.on('checkbox(checkAll)', function(data){
    if(data.elem.checked){
      jq("input[type='checkbox']").prop('checked',true);
    }else{
      jq("input[type='checkbox']").prop('checked',false);
    }
    form.render('checkbox');
  });  

  form.on('checkbox(checkOne)', function(data){
    var is_check = true;
    if(data.elem.checked){
      jq("input[lay-filter='checkOne']").each(function(){
        if(!jq(this).prop('checked')){ is_check = false; }
      });
      if(is_check){
        jq("input[lay-filter='checkAll']").prop('checked',true);
      }
    }else{
      jq("input[lay-filter='checkAll']").prop('checked',false);
    } 
    form.render('checkbox');
  });

  form.on('submit(delete)', function(data){
    var is_check = false;
    jq("input[lay-filter='checkOne']").each(function(){
      if(jq(this).prop('checked')){ is_check = true; }
    });
    if(!is_check){
      layer.msg('请选择数据', {icon: 2,anim: 6,time: 1000});
      return false;
    }
    layer.confirm('确定批量删除?', function(index){
      loading = layer.load(2, {
        shade: [0.2,'#000']
      });
      var param = data.field;
      jq.post('<?php echo url("news/delss"); ?>',param,function(data){
        if(data.code == 200){
          layer.close(loading);
          layer.msg(data.msg, {icon: 1, time: 1000}, function(){
            location.reload();
          });
        }else{
          layer.close(loading);
          layer.msg(data.msg, {icon: 2,anim: 6, time: 1000});
        }
      });
    });
    return false;
  });

})
</script>
</div>
</div>
<div class="footer">
  <p class="bq">
  <a style="position: absolute;color: #FFF;display: none;" class="banquan" target="_blank" href="https://www.guojiz.com/">国际网址导航</a>
  </p>
</div>
</body>
</news>