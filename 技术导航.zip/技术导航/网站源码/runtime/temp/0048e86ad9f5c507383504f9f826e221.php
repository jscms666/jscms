<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:44:"./application/admin/view/category_index.html";i:1560082670;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_header.html";i:1561296954;s:68:"/www/wwwroot/666.36yunhu.cn/application/admin/view/index_footer.html";i:1559657242;}*/ ?>
<!DOCTYPE html>
<html>
<head>  
  <title>Guojiz国际网址后台管理系统</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href="/favicon.ico" rel="shortcut icon">
  <link rel="stylesheet" href="/public/layui/css/layui.css">
  <link rel="stylesheet" href="/public/css/global.css">
  <script src="/public/layui/layui.js" type="text/javascript"></script>
  <script src="/public/js/jquery-3.4.1.min.js" type="text/javascript"></script>
</head>
<body>
<style type="text/css">
.layui-form-checkbox {height: 22px;line-height: 20px;margin-right: 0px;padding-right: 20px;}
.layui-form-checkbox i {right: 3px;width: 20px;font-size: 16px;top: 2px;}
</style>
<div class="fly-panel fly-panel-user">
<div class="tpt—admin">
<div class="tpt—btn">
<a href="<?php echo url('category/add'); ?>"><i class="layui-icon">&#xe608;</i> 添加分类</a>
</div>

<form method="post" class="cl">
<table width="100%">
<tr>
<th width="5%" align="center">分类ID</th>
<th width="20%" align="center">分类名称</th>
<th width="10%" align="center">是否显示</th>
<th width="10%" align="center">分类图片</th>
<th width="25%" align="center">分类连接</th>
<th width="10%" align="center">添加时间</th>
<th width="10%" align="center">基本操作</th>
</tr>
<?php if(is_array($tptc) || $tptc instanceof \think\Collection || $tptc instanceof \think\Paginator): $i = 0; $__LIST__ = $tptc;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<tr>
<td align="center"><?php echo $vo['id']; ?></td>
<td style="padding-left: 20px;"><a target="_blank" href="/index.php/view/<?php echo $vo['id']; ?>.html"><?php if($vo['level'] != 0): ?>|----------<?php endif; ?><?php echo $vo['name']; ?></a></td>
<td align="center">
<a change="<?php echo $vo['id']; ?>" onclick="changeshow(this);" <?php if($vo['show'] == 1): ?>class="layui-unselect layui-form-switch layui-form-onswitch"<?php else: ?>class="layui-unselect layui-form-switch"<?php endif; ?>>
<em>显示</em><i></i>
</a>
 
<td align="center"><?php if($vo['pic'] != ''): ?><img style="border: 1px solid #CDCDCD;padding: 3px;border-radius: 2px;" src="<?php echo $vo['pic']; ?>" height="25"><?php else: ?>暂无图片<?php endif; ?></td>
<td style="padding-left: 20px;">/index.php/view/<?php echo $vo['id']; ?>.html</td>
<td align="center"><?php echo date("Y-m-d",$vo['time']); ?></td>
<td align="center">
<a class="layui-btn layui-btn-mini layui-btn-warm" href="<?php echo url('category/edit',array('id'=>$vo['id'])); ?>">修改</a> <a class="layui-btn layui-btn-mini layui-btn-danger del_btn" member-id="<?php echo $vo['id']; ?>" title="删除" nickname="<?php echo $vo['name']; ?>">删除</a>
</td>
</tr>
<?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</form>
</div>
</div>
<script>
function changeshow(o){
  var change=$(o).attr("change");
  $.ajax({
	  type:"post",
	  dataType:"json",
      data:{change:change},
	  url:"<?php echo url('category/changeshow'); ?>",
	  success:function(data){
		  if(data == 1){
			  $(o).attr("class","layui-unselect layui-form-switch");
	      }else{
			  $(o).attr("class","layui-unselect layui-form-switch layui-form-onswitch");
	      }
	  }
  });
}
function changesidebar(o){
  var change=$(o).attr("change");
  $.ajax({
	  type:"post",
	  dataType:"json",
      data:{change:change},
	  url:"<?php echo url('category/changesidebar'); ?>",
	  success:function(data){
		  if(data == 1){
			  $(o).attr("class","layui-unselect layui-form-switch");
	      }else{
			  $(o).attr("class","layui-unselect layui-form-switch layui-form-onswitch");
	      }
	  }
  });
}
</script>
<script>
layui.use('form',function(){
  var form = layui.form()
  ,jq = layui.jquery;

  jq('.del_btn').click(function(){
    var name = jq(this).attr('nickname');
    var id = jq(this).attr('member-id');
    layer.confirm('确定删除【'+name+'】?', function(index){
      loading = layer.load(2, {
        shade: [0.2,'#000']
      });
      jq.post('<?php echo url("category/dels"); ?>',{'id':id},function(data){
        if(data.code == 200){
          layer.close(loading);
          layer.msg(data.msg, {icon: 1, time: 1000}, function(){
            location.reload();
          });
        }else{
          layer.close(loading);
          layer.msg(data.msg, {icon: 2, anim: 6, time: 1000});
        }
      });
    });
  });

})
</script>
<div class="footer">
  <p class="bq">
  <a style="position: absolute;color: #FFF;display: none;" class="banquan" target="_blank" href="https://www.guojiz.com/">国际网址导航</a>
  </p>
</div>
</body>
</html>


