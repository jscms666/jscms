<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use Captcha\Captcha;
use think\Cache;
use think\Config;
use think\Session;
use think\Request;
class Wang extends Controller
{
    public function _initialize()
    {
        $show['show'] = 1;
        $tpto = Db::name('category')->where($show)->order('sort desc')->limit(120)->select();
        $this->assign('tpto', $tpto);   
        $GZdh = Db::name('links')->where($show)->order('px desc')->select();
        $this->assign('GZdh', $GZdh);
        $wang = Db::name('wangcate')->where($show)->order('sort desc')->limit(120)->select();
        $this->assign('wang', $wang);   
        $keyss = Db::name('member')->where('userid = 1')->value('key');
  $this->assign('keyss', $keyss);
    }
  
    public function index()
    {
        $key = Db::name('member')->where('userid = 1')->value('key');
        if ($key == '0' or $key == '') {
          return $this->error(config('web.GZ_TS'));
        } else {
        $map['open'] = 1;
        $tptc = Db::name('wang')->alias('w')->join('wangcate c', 'c.id=w.tid')->field('w.*,c.id as cid,c.name')->where('open = 1')->order('id desc')->paginate(12);
        $this->assign('tptc', $tptc);
       }
        return view();
    }
    public function w()
    {
        $key = Db::name('member')->where('userid = 1')->value('key');
        if ($key == '0' or $key == '') {
          return $this->error(config('web.GZ_TS'));
        } else {
        $id = input('id');
        if (empty($id)) {
            return $this->error('亲！你迷路了');
        } else {
            $wangcate = Db::name('wangcate');
            $c = $wangcate->where("id = {$id}")->find();
            if ($c) {
                $html = Db::name('wang');
                $open['open'] = 1;
                $id = $c['id'];
                $name = $c['name'];
                $tptc = $html->alias('f')->join('wangcate c', 'c.id=f.tid')->join('member m', 'm.userid=f.uid')->field('f.*,c.id as cid,m.userid,m.userhead,m.username,c.name')->where("f.tid={$id}")->where($open)->order('f.id desc')->paginate(12);
                $this->assign('tptc', $tptc);
                $this->assign('name', $name);
                $this->assign('id', $id);
                return view();
            } else {
                $this->error("亲！你迷路了！");
            }
        }
      }
    }
 
    public function wangdj()
    {
      $id = input('id'); 
      Db::name('wang')->where("id = {$id}")->setInc('view', 1);
      return view();
    }



}