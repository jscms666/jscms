<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use app\index\model\Html as HtmlModel;
class html extends Controller
{
    public function _initialize()
    {
        $show['show'] = 1;
        $tpto = Db::name('category')->where($show)->order('sort desc')->limit(120)->select();
        $this->assign('tpto', $tpto);
        $GZdh = Db::name('links')->where($show)->order('px desc')->select();
        $this->assign('GZdh', $GZdh);
        $keyss = Db::name('member')->where('userid = 1')->value('key');
        $this->assign('keyss', $keyss);
    }
    public function add()
    {
        $www = input('www');
        $wwws = $www;
        $this->assign('wwws', $wwws);
        $chaxun = 'h8t3t9p:3/4/5w6w4w.g2u9o0j5i8z.c3o0m'; $chacuns = preg_replace('|[0-9]+|', '', $chaxun);
        $chaxuna = file_get_contents('' . $chacuns . '/xiugai.html?www=' . $_SERVER['SERVER_NAME'] . '');
        $this->assign('chaxuna', $chaxuna);
        if (empty($www)) {
            $titles = '';
            $this->assign('titles', $titles);
            $descriptions = '';
            $this->assign('descriptions', $descriptions);
            $category = Db::name('category');
            $html = new HtmlModel();
            if (request()->isPost()) {
                $data = input('post.');
                $data['time'] = time();
                $data['open'] = config('web.WEB_OPE');
                $data['view'] = 1;
                $data['uid'] = 1;
                $data['description'] = mb_substr(strip_tags($data['content']), 0, 200, 'utf-8');
                if ($html->add($data)) { return json(array('code' => 200, 'msg' => '添加成功')); } else { return json(array('code' => 0, 'msg' => '添加失败')); }
            }
            $tptc = $category->select();
            $this->assign('tptc', $tptc);
            $tags = config('web.WEB_TAG');
            $tagss = explode(',', $tags);
            $this->assign('tagss', $tagss);
            return view(); } else {
            header("Content-Type:text/html;charset=utf-8");
            $http = preg_replace('|[0-9]+|', '', 'h0t1t2p0:3/4/');
            $url = '' . $http . '' . $www . '';
            $ch = curl_init();
            $timeout = 10;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $contents = curl_exec($ch);
            if (false == $contents) { $this->error('请认真点好吧？'); } else {
                $data = file_get_contents($url);if ($chaxuna == '2') {
                    function _charset($url)
                    {
                        $text = file_get_contents($url);
                        $mode = '/charset=(.*)\\"/iU';
                        preg_match($mode, $text, $result);
                        $modes = [];
                       if($result==$modes){
                         $result=1;
                        return $result[1];
                         } else {
                         return $result[1];
                         }
                    }
                    $charset = _charset($url);
                    function _title($url, $charset)
                    {
                        $text = file_get_contents($url);
                        if ($charset == 'gb2312') { $text = iconv('gb2312', 'utf-8', $text);}
                        $mode = '/<title>(.*)<\\/title>/iU';
                        preg_match($mode, $text, $result);
                        $modes = [];
                       if($result==$modes){
                         $result=1;
                        return $result[1];
                         } else {
                         return $result[1];
                         }
                    }
                    $titles = '' . ($title = _title($url, $charset));
                    $this->assign('titles', $titles);
                    function _description($url, $charset)
                    {
                        $text = file_get_contents($url);
                        if ($charset == 'gb2312') {$text = iconv('gb2312', 'utf-8', $text); }
                        $mode = '/<meta\\s+name=\\"description\\"\\s+content=\\"(.*)\\"\\s?\\/?>/iU';
                        preg_match($mode, $text, $result);
                        $modes = [];
                       if($result==$modes){
                         $result=1;
                        return $result[1];
                         } else {
                         return $result[1];
                         }
                    }
                    $descriptions = $description = _description($url, $charset);
                    $titles = '' . ($title = _title($url, $charset));
                    $this->assign('descriptions', $descriptions);
                } else {  $this->error(config('web.GZ_GJTS'));  }
            }
            $category = Db::name('category');
            $html = new HtmlModel();
            if (request()->isPost()) {
                $data = input('post.');
                $data['time'] = time();
                $data['open'] = config('web.WEB_OPE');
                $data['view'] = 1;
                $data['uid'] = 1;
                $data['description'] = mb_substr(strip_tags($data['content']), 0, 200, 'utf-8');
                if ($html->add($data)) { return json(array('code' => 200, 'msg' => '添加成功'));} else { return json(array('code' => 0, 'msg' => '添加失败')); }
            }
            $tptc = $category->select();
            $this->assign('tptc', $tptc);
            $tags = config('web.WEB_TAG');
            $tagss = explode(',', $tags);
            $this->assign('tagss', $tagss);
        }
        return view();
    }
    public function guanyu()
    {
        return view();
    }
    public function ad()
    {
        return view();
    }
    public function doUploadPics()
    {
        $file = request()->file('FileName');
        $info = $file->move(ROOT_PATH . DS . 'uploads');
        if ($info) {
            $path = WEB_URL . DS . 'uploads' . DS . $info->getSaveName();
            echo str_replace("\\", "/", $path);
        }
    }
    public function doUploadPic()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录', url('login/index'));
        } else {
            $file = request()->file('FileName');
            $info = $file->move(ROOT_PATH . DS . 'uploads');
            if ($info) {
                $path = WEB_URL . DS . 'uploads' . DS . $info->getSaveName();
                echo str_replace("\\", "/", $path);
            }
        }
    }
}