
          
<?php

return [
    'type'            => 'mysql',
    'hostname'        => '127.0.0.1',
    'database'        => 'sql_666_36yunhu_',
    'username'        => 'sql_666_36yunhu_',
    'password'        => 'j3w7G24XGsRmRN4z',
    'mis'             => '89904533551891251810437689729122',
    'hostport'        => '3306',
    'dsn'             => '',
    'params'          => [],
    'charset'         => 'utf8',
    'prefix'          => 'my_', 
    'debug'           => true,
    'deploy'          => 0,
    'rw_separate'     => false,
    'master_num'      => 1,
    'slave_no'        => '',
    'fields_strict'   => true,
    'resultset_type'  => 'array',
    'auto_timestamp'  => false,
    'datetime_format' => 'Y-m-d H:i:s',
    'sql_explain'     => false,
    'builder'         => '',
    'query'           => '\think\db\Query',
];