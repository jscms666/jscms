<?php
return [
    
	'template'=> [
    'view_suffix' => 'html',
	'view_depr'    => '_',
    ],

];
