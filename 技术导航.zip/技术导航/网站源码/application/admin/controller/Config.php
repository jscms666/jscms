<?php
namespace app\admin\controller;
use think\Controller;
class Config extends Common
{
 
	public function index()
    {
       return view();
    }

	public function add()
    {
       $path = 'application/extra/web.php';
       $file = include $path;      
       $config = array(
           'PZ-FG' => input('PZ-FG'),
           'PZ-J' => input('PZ-J'),
           'PZ-ZD' => input('PZ-ZD'),
           'PZ-GJ' => input('PZ-GJ'),
           'PZ-PHB' => input('PZ-PHB'),
           'PZ-CAI' => input('PZ-CAI'),
           'PZ-NEW' => input('PZ-NEW'),
           'PZ-FL' => input('PZ-FL'),
           'PZ-NEWS' => input('PZ-NEWS'),
           'PZ-TIME' => input('PZ-TIME'),
           'PZ-YX' => input('PZ-YX'),
           'PZ-GD' => input('PZ-GD'),
           'GZ_PD' => input('GZ_PD'),
           'id' => input('id'),
           'logo' => input('logo'),
           'WEB_HZ' => input('WEB_HZ'),
           'WEB_TJ' => input('WEB_TJ'),
           'WEB_TIT' => input('WEB_TIT'),
		   'WEB_COM' => input('WEB_COM'),
		   'WEB_AUT' => input('WEB_AUT'),
		   'WEB_QQ' => input('WEB_QQ'),
		   'WEB_ICP' => input('WEB_ICP'),
		   'WEB_REG' => input('WEB_REG'),
		   'WEB_KEY' => input('WEB_KEY'),
		   'WEB_DES' => input('WEB_DES'),
		   'WEB_TAG' => input('WEB_TAG'),
		   'WEB_TPT' => input('WEB_TPT'),
		   'WEB_URL' => input('WEB_URL'),
		   'WEB_OPE' => input('WEB_OPE'),
       );
 
       $res = array_merge($file, $config);
       $str = '<?php return [';
        
       foreach ($res as $key => $value){
           $str .= '\''.$key.'\''.'=>'.'\''.$value.'\''.',';
       };
       $str .= ']; ';
       if(file_put_contents($path, $str)){
           return json(array('code'=>200,'msg'=>'修改成功'));
       }else {
           return json(array('code'=>0,'msg'=>'修改失败'));
       }
    }

	
    

}
