<?php include('system/inc.php');
include 'system/list.php';
$page=$_GET['page'];
include('template/'.$mkcms_bdyun.'/dongman.php');?>