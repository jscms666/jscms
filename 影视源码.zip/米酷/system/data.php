<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_USERNAME', 'root'); //数据库用户名
define('DATA_PASSWORD', 'root'); //数据库密码
define('DATA_NAME', 'root');     //数据库名称
?>