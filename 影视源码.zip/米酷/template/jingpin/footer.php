<div class="stui-foot clearfix">
	<div class="container">
		<div class="row">		
			<div class="col-pd text-center">
<p class="text-center"><span style="color:#000;text-align:center;"><?php echo $mkcms_copyright;?></span></p>
<p class="text-center"><?php echo $mkcms_tongji;?></p>
</div>
</div>
</div>
</div>
</div>
<div id="footer" class="border-t hidden-lg hidden-md" >
<ul class="flex-wrap" style="font-weight:bold">
<a class="flex-con <?php echo $index;?>" href="<?php echo $mkcms_domain;?>"><li onclick="randomSwitchBtn( this );">首页</li>
<a class="flex-con <?php echo $cx;?>" href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>"><li onclick="randomSwitchBtn( this );">抢先</li></a>
<a class="flex-con <?php echo $dt;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'hall.html';}else{echo 'hall.php';}?>"><li onclick="randomSwitchBtn( this );">大厅</li></a>
<a class="flex-con <?php echo $fl;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fuli.html';}else{echo 'fuli.php';}?>"><li onclick="randomSwitchBtn( this );">福利</li></a>
<a class="flex-con <?php echo $hy;?>" href="<?php echo $mkcms_domain;?>ucenter"><li onclick="randomSwitchBtn( this );">我的</li></a>
</ul>
 </div>
<ul class="stui-extra clearfix hidden-xs">
<li><a class="backtop" href="javascript:scroll(0,0)" style="display: block;"><i class="icon iconfont icon-less"></i></a></li>
<li class="visible-xs"><a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a></li>
<li class="hidden-xs"><span><i class="icon iconfont icon-qrcode"></i></span>
<div class="sideslip">
<div class="col-pd">
<img width="150" height="150" src="http://www.hez70.com/qrcode/qr.php?url=<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>">
<p class="text-center font-12">扫码用手机访问</p>
</div>
</div>
</li>
<li title="会员中心"><a class="open-share" href="<?php echo $mkcms_domain;?>ucenter"><i class="icon iconfont icon-smile"></i></a></li>
<li><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "book.html";}else {echo "book.php";}?>"><i class="icon iconfont icon-comments"></i></a></li>
</ul>
</div>
</body>
</html>