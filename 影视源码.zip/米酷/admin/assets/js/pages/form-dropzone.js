$(document).ready(function(){
	/*------ Dropzone Init ------*/
	$(".dropzone").dropzone();
});

