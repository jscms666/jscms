<?php  include 'head.php';?>
<title>App下载-<?php echo $mkcms_seoname;?></title> 
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
<div class="row">
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel_bd">
<ul class="stui-vodlist clearfix" style="text-align:center"> 
<iframe src="/down.php" width="90%" height="600" border="0" marginwidth="0" marginheight="0"  frameborder="no"  allowtransparency="yes"style="padding: 10px;border-radius: 5px;background-color: #F5F5F5;"></iframe>
</ul>
</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>