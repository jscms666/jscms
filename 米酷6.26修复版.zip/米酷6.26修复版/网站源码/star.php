<?php 
include('system/inc.php');
$mxq=$_GET['wd'];
$leixing=$_GET['tab'];
include('template/'.$mkcms_bdyun.'/star.php');?>