<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_NAME', 'movie'); //数据库名
define('DATA_USERNAME', '123456'); //数据库用户名
define('DATA_PASSWORD', '123456'); //数据库密码
?>