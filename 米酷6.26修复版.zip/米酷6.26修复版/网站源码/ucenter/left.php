<div class="col-md-2">
<div class="sidenav">
<ul class="list-group">
<li class="list-group-heading" style="margin-top:0px;">会员中心</li>
<li class="list-group-item " ><a href="index.php"><i class="iconfont icon-pseson"></i> 账号中心</a></li>
<li class="list-group-item " ><a href="userinfo.php"><i class="iconfont icon-shezhi"></i> 个人设置</a></li>
<li class="list-group-item "  ><a href="mingxi.php"><i class="iconfont icon-group1"></i> 购买会员</a></li>
<li class="list-group-item "><a href="kami.php"><i class="iconfont icon-fire"></i> 卡密兑换</a></li>
<li class="list-group-item "><a href="yaoqing.php"><i class="iconfont icon-sms"></i> 邀请记录</a></li>
<li class="list-group-item "><a href="fav.php"><i class="iconfont icon-bookmark"></i> 收藏记录</a></li>
<li class="list-group-item "><a href="exit.php"><i class="iconfont icon-tuichu"></i> 退出登录</a></li>
</ul>
</div>
</div>