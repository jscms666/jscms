<?php include('system/inc.php');
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
include('template/'.$mkcms_bdyun.'/yplay.php');?>